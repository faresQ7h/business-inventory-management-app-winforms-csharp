﻿namespace Business_Inventory_Management_System
{
    partial class FormHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            lblOrders = new Label();
            lblThisMonthStatus = new Label();
            lblDeliveredOrders = new Label();
            lblUndeliveredOrders = new Label();
            lblProfit = new Label();
            lblTotalProfit = new Label();
            lblNumberOfDeliveredOrders = new Label();
            lblNumberOfUndeliveredOrders = new Label();
            lblClock = new Label();
            timerClock = new System.Windows.Forms.Timer(components);
            panelClock = new Panel();
            lblDate = new Label();
            dgvUndeliveredOrders = new DataGridView();
            lblNoOrdersThisMonth = new Label();
            panelClock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUndeliveredOrders).BeginInit();
            SuspendLayout();
            // 
            // lblOrders
            // 
            lblOrders.AutoSize = true;
            lblOrders.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblOrders.ForeColor = SystemColors.ButtonHighlight;
            lblOrders.Location = new Point(3, 216);
            lblOrders.Name = "lblOrders";
            lblOrders.Size = new Size(361, 35);
            lblOrders.TabIndex = 1;
            lblOrders.Text = "Orders To Deliver This Month";
            // 
            // lblThisMonthStatus
            // 
            lblThisMonthStatus.AutoSize = true;
            lblThisMonthStatus.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblThisMonthStatus.ForeColor = SystemColors.ButtonHighlight;
            lblThisMonthStatus.Location = new Point(3, 109);
            lblThisMonthStatus.Name = "lblThisMonthStatus";
            lblThisMonthStatus.Size = new Size(320, 35);
            lblThisMonthStatus.TabIndex = 3;
            lblThisMonthStatus.Text = "This Month Business Stats";
            // 
            // lblDeliveredOrders
            // 
            lblDeliveredOrders.Anchor = AnchorStyles.Top;
            lblDeliveredOrders.AutoSize = true;
            lblDeliveredOrders.Font = new Font("Segoe UI", 10.8F);
            lblDeliveredOrders.ForeColor = Color.Black;
            lblDeliveredOrders.Location = new Point(140, 148);
            lblDeliveredOrders.Name = "lblDeliveredOrders";
            lblDeliveredOrders.Size = new Size(149, 25);
            lblDeliveredOrders.TabIndex = 4;
            lblDeliveredOrders.Text = "Delivered Orders:";
            // 
            // lblUndeliveredOrders
            // 
            lblUndeliveredOrders.Anchor = AnchorStyles.Top;
            lblUndeliveredOrders.AutoSize = true;
            lblUndeliveredOrders.Font = new Font("Segoe UI", 10.8F);
            lblUndeliveredOrders.ForeColor = Color.Black;
            lblUndeliveredOrders.Location = new Point(120, 174);
            lblUndeliveredOrders.Name = "lblUndeliveredOrders";
            lblUndeliveredOrders.Size = new Size(169, 25);
            lblUndeliveredOrders.TabIndex = 5;
            lblUndeliveredOrders.Text = "Undelivered Orders:";
            // 
            // lblProfit
            // 
            lblProfit.Anchor = AnchorStyles.Top;
            lblProfit.AutoSize = true;
            lblProfit.Font = new Font("Segoe UI", 10.8F);
            lblProfit.ForeColor = Color.Black;
            lblProfit.Location = new Point(458, 161);
            lblProfit.Name = "lblProfit";
            lblProfit.Size = new Size(59, 25);
            lblProfit.TabIndex = 6;
            lblProfit.Text = "Profit:";
            // 
            // lblTotalProfit
            // 
            lblTotalProfit.Anchor = AnchorStyles.Top;
            lblTotalProfit.AutoSize = true;
            lblTotalProfit.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblTotalProfit.ForeColor = Color.LightCyan;
            lblTotalProfit.Location = new Point(512, 163);
            lblTotalProfit.Name = "lblTotalProfit";
            lblTotalProfit.Size = new Size(60, 23);
            lblTotalProfit.TabIndex = 7;
            lblTotalProfit.Text = "0.00 $";
            // 
            // lblNumberOfDeliveredOrders
            // 
            lblNumberOfDeliveredOrders.Anchor = AnchorStyles.Top;
            lblNumberOfDeliveredOrders.AutoSize = true;
            lblNumberOfDeliveredOrders.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblNumberOfDeliveredOrders.ForeColor = Color.LightCyan;
            lblNumberOfDeliveredOrders.Location = new Point(284, 151);
            lblNumberOfDeliveredOrders.Name = "lblNumberOfDeliveredOrders";
            lblNumberOfDeliveredOrders.Size = new Size(25, 23);
            lblNumberOfDeliveredOrders.TabIndex = 8;
            lblNumberOfDeliveredOrders.Text = "0 ";
            // 
            // lblNumberOfUndeliveredOrders
            // 
            lblNumberOfUndeliveredOrders.Anchor = AnchorStyles.Top;
            lblNumberOfUndeliveredOrders.AutoSize = true;
            lblNumberOfUndeliveredOrders.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblNumberOfUndeliveredOrders.ForeColor = Color.LightCyan;
            lblNumberOfUndeliveredOrders.Location = new Point(284, 176);
            lblNumberOfUndeliveredOrders.Name = "lblNumberOfUndeliveredOrders";
            lblNumberOfUndeliveredOrders.Size = new Size(25, 23);
            lblNumberOfUndeliveredOrders.TabIndex = 9;
            lblNumberOfUndeliveredOrders.Text = "0 ";
            // 
            // lblClock
            // 
            lblClock.Anchor = AnchorStyles.Top;
            lblClock.BorderStyle = BorderStyle.FixedSingle;
            lblClock.Font = new Font("MS Reference Sans Serif", 22.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblClock.Location = new Point(305, 1);
            lblClock.Name = "lblClock";
            lblClock.Size = new Size(160, 67);
            lblClock.TabIndex = 10;
            lblClock.Text = "--:--";
            lblClock.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // timerClock
            // 
            timerClock.Enabled = true;
            timerClock.Interval = 30000;
            timerClock.Tick += timerClock_Tick;
            // 
            // panelClock
            // 
            panelClock.Controls.Add(lblDate);
            panelClock.Controls.Add(lblClock);
            panelClock.Dock = DockStyle.Top;
            panelClock.Location = new Point(0, 0);
            panelClock.Name = "panelClock";
            panelClock.Size = new Size(754, 106);
            panelClock.TabIndex = 11;
            // 
            // lblDate
            // 
            lblDate.Anchor = AnchorStyles.Top;
            lblDate.Font = new Font("MS Reference Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDate.Location = new Point(252, 72);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(264, 31);
            lblDate.TabIndex = 11;
            lblDate.Text = "Mon 16 jenuary";
            lblDate.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // dgvUndeliveredOrders
            // 
            dgvUndeliveredOrders.AllowUserToAddRows = false;
            dgvUndeliveredOrders.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvUndeliveredOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvUndeliveredOrders.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvUndeliveredOrders.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvUndeliveredOrders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvUndeliveredOrders.DefaultCellStyle = dataGridViewCellStyle2;
            dgvUndeliveredOrders.Location = new Point(12, 249);
            dgvUndeliveredOrders.Name = "dgvUndeliveredOrders";
            dgvUndeliveredOrders.ReadOnly = true;
            dgvUndeliveredOrders.RowHeadersVisible = false;
            dgvUndeliveredOrders.RowHeadersWidth = 51;
            dgvUndeliveredOrders.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvUndeliveredOrders.Size = new Size(730, 300);
            dgvUndeliveredOrders.TabIndex = 0;
            // 
            // lblNoOrdersThisMonth
            // 
            lblNoOrdersThisMonth.Anchor = AnchorStyles.None;
            lblNoOrdersThisMonth.AutoSize = true;
            lblNoOrdersThisMonth.BackColor = Color.Gainsboro;
            lblNoOrdersThisMonth.Font = new Font("Segoe UI", 11F);
            lblNoOrdersThisMonth.ForeColor = Color.Teal;
            lblNoOrdersThisMonth.Location = new Point(250, 386);
            lblNoOrdersThisMonth.Name = "lblNoOrdersThisMonth";
            lblNoOrdersThisMonth.Size = new Size(266, 25);
            lblNoOrdersThisMonth.TabIndex = 1;
            lblNoOrdersThisMonth.Text = "There are no orders to deliver.";
            lblNoOrdersThisMonth.Visible = false;
            // 
            // FormHome
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(754, 561);
            Controls.Add(lblNoOrdersThisMonth);
            Controls.Add(dgvUndeliveredOrders);
            Controls.Add(panelClock);
            Controls.Add(lblNumberOfUndeliveredOrders);
            Controls.Add(lblNumberOfDeliveredOrders);
            Controls.Add(lblTotalProfit);
            Controls.Add(lblProfit);
            Controls.Add(lblUndeliveredOrders);
            Controls.Add(lblDeliveredOrders);
            Controls.Add(lblThisMonthStatus);
            Controls.Add(lblOrders);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormHome";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormHome";
            Load += FormHome_Load;
            panelClock.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvUndeliveredOrders).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblOrders;
        private Label lblThisMonthStatus;
        private Label lblDeliveredOrders;
        private Label lblUndeliveredOrders;
        private Label lblProfit;
        private Label lblTotalProfit;
        private Label lblNumberOfDeliveredOrders;
        private Label lblNumberOfUndeliveredOrders;
        private Label lblClock;
        private System.Windows.Forms.Timer timerClock;
        private Panel panelClock;
        private DataGridView dgvUndeliveredOrders;
        private Label lblNoOrdersThisMonth;
        private Label lblDate;
    }
}