﻿namespace Business_Inventory_Management_System
{
    partial class FormOrderInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOrderInfo));
            lblMsg = new Label();
            tbxID = new TextBox();
            lblID = new Label();
            btnCancel = new Button();
            btnConfirm = new Button();
            lblCustomer = new Label();
            tbxDescription = new TextBox();
            lblDescription = new Label();
            lblStatus = new Label();
            comboStatus = new ComboBox();
            dgvOrderItems = new DataGridView();
            btnDelete = new Button();
            lblQuantity = new Label();
            lblProduct = new Label();
            nudQuantity = new NumericUpDown();
            comboProducts = new ComboBox();
            comboCustomer = new ComboBox();
            lblTotal = new Label();
            lblEstimatedDeliveryDate = new Label();
            dtpEstimatedDeliveryDate = new DateTimePicker();
            lblItemProductRequired = new Label();
            lblEstimatedDeliveryRequired = new Label();
            lblStatusRequired = new Label();
            lblCustomerRequired = new Label();
            lblOrderItems = new Label();
            lblItemQuantityRequired = new Label();
            lblEmptyOrderItems = new Label();
            btnAdd = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvOrderItems).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
            SuspendLayout();
            // 
            // lblMsg
            // 
            lblMsg.Font = new Font("Segoe UI", 10F);
            lblMsg.ForeColor = Color.Gold;
            lblMsg.Location = new Point(9, 475);
            lblMsg.Name = "lblMsg";
            lblMsg.Size = new Size(473, 37);
            lblMsg.TabIndex = 55;
            lblMsg.Text = "Msg";
            lblMsg.TextAlign = ContentAlignment.MiddleCenter;
            lblMsg.Visible = false;
            // 
            // tbxID
            // 
            tbxID.Location = new Point(166, 22);
            tbxID.Name = "tbxID";
            tbxID.PlaceholderText = "Enter ID";
            tbxID.Size = new Size(293, 27);
            tbxID.TabIndex = 54;
            tbxID.Visible = false;
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Font = new Font("Segoe UI", 10F);
            lblID.ForeColor = SystemColors.ControlLightLight;
            lblID.Location = new Point(136, 24);
            lblID.Name = "lblID";
            lblID.Size = new Size(27, 23);
            lblID.TabIndex = 53;
            lblID.Text = "ID";
            lblID.Visible = false;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(72, 520);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(167, 37);
            btnCancel.TabIndex = 52;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnConfirm
            // 
            btnConfirm.BackColor = Color.DarkSlateGray;
            btnConfirm.Enabled = false;
            btnConfirm.FlatAppearance.BorderColor = Color.Black;
            btnConfirm.FlatStyle = FlatStyle.Flat;
            btnConfirm.ForeColor = Color.Black;
            btnConfirm.Location = new Point(254, 520);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(167, 37);
            btnConfirm.TabIndex = 51;
            btnConfirm.Text = "Confirm";
            btnConfirm.UseVisualStyleBackColor = false;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // lblCustomer
            // 
            lblCustomer.AutoSize = true;
            lblCustomer.Font = new Font("Segoe UI", 10F);
            lblCustomer.ForeColor = SystemColors.ControlLightLight;
            lblCustomer.Location = new Point(79, 67);
            lblCustomer.Name = "lblCustomer";
            lblCustomer.Size = new Size(84, 23);
            lblCustomer.TabIndex = 43;
            lblCustomer.Text = "Customer";
            // 
            // tbxDescription
            // 
            tbxDescription.Location = new Point(166, 202);
            tbxDescription.Multiline = true;
            tbxDescription.Name = "tbxDescription";
            tbxDescription.PlaceholderText = "Enter description";
            tbxDescription.ScrollBars = ScrollBars.Vertical;
            tbxDescription.Size = new Size(293, 27);
            tbxDescription.TabIndex = 57;
            // 
            // lblDescription
            // 
            lblDescription.AutoSize = true;
            lblDescription.Font = new Font("Segoe UI", 10F);
            lblDescription.ForeColor = SystemColors.ControlLightLight;
            lblDescription.Location = new Point(67, 202);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(96, 23);
            lblDescription.TabIndex = 56;
            lblDescription.Text = "Description";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 10F);
            lblStatus.ForeColor = SystemColors.ControlLightLight;
            lblStatus.Location = new Point(107, 112);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(56, 23);
            lblStatus.TabIndex = 58;
            lblStatus.Text = "Status";
            // 
            // comboStatus
            // 
            comboStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            comboStatus.FormattingEnabled = true;
            comboStatus.Items.AddRange(new object[] { "Undelivered", "Delivered", "Cancelled" });
            comboStatus.Location = new Point(166, 112);
            comboStatus.Name = "comboStatus";
            comboStatus.Size = new Size(293, 28);
            comboStatus.TabIndex = 59;
            comboStatus.SelectedIndexChanged += comboStatus_SelectedIndexChanged;
            // 
            // dgvOrderItems
            // 
            dgvOrderItems.AllowUserToAddRows = false;
            dgvOrderItems.AllowUserToDeleteRows = false;
            dgvOrderItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvOrderItems.BackgroundColor = SystemColors.Window;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Microsoft YaHei UI", 6.5F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvOrderItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvOrderItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft YaHei UI", 7.5F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvOrderItems.DefaultCellStyle = dataGridViewCellStyle2;
            dgvOrderItems.EditMode = DataGridViewEditMode.EditOnEnter;
            dgvOrderItems.Location = new Point(166, 303);
            dgvOrderItems.Name = "dgvOrderItems";
            dgvOrderItems.RowHeadersVisible = false;
            dgvOrderItems.RowHeadersWidth = 51;
            dgvOrderItems.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgvOrderItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvOrderItems.Size = new Size(293, 111);
            dgvOrderItems.TabIndex = 60;
            dgvOrderItems.CellDoubleClick += dgvOrderItems_CellDoubleClick;
            dgvOrderItems.CellEndEdit += dgvOrderItems_CellEndEdit;
            dgvOrderItems.CellValidating += dgvOrderItems_CellValidating;
            dgvOrderItems.RowsAdded += dgvOrderItems_RowsAdded;
            dgvOrderItems.RowsRemoved += dgvOrderItems_RowsRemoved;
            dgvOrderItems.SelectionChanged += dgvOrderItems_SelectionChanged;
            // 
            // btnDelete
            // 
            btnDelete.Enabled = false;
            btnDelete.FlatStyle = FlatStyle.System;
            btnDelete.Location = new Point(81, 358);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(82, 29);
            btnDelete.TabIndex = 66;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // lblQuantity
            // 
            lblQuantity.AutoSize = true;
            lblQuantity.Font = new Font("Segoe UI", 9F);
            lblQuantity.ForeColor = SystemColors.ControlLightLight;
            lblQuantity.Location = new Point(98, 279);
            lblQuantity.Name = "lblQuantity";
            lblQuantity.Size = new Size(65, 20);
            lblQuantity.TabIndex = 69;
            lblQuantity.Text = "Quantity";
            // 
            // lblProduct
            // 
            lblProduct.AutoSize = true;
            lblProduct.Font = new Font("Segoe UI", 9F);
            lblProduct.ForeColor = SystemColors.ControlLightLight;
            lblProduct.Location = new Point(103, 246);
            lblProduct.Name = "lblProduct";
            lblProduct.Size = new Size(60, 20);
            lblProduct.TabIndex = 67;
            lblProduct.Text = "Product";
            // 
            // nudQuantity
            // 
            nudQuantity.Location = new Point(166, 275);
            nudQuantity.Maximum = new decimal(new int[] { 1316134911, 2328, 0, 0 });
            nudQuantity.Name = "nudQuantity";
            nudQuantity.Size = new Size(222, 27);
            nudQuantity.TabIndex = 70;
            nudQuantity.TextAlign = HorizontalAlignment.Right;
            nudQuantity.ThousandsSeparator = true;
            nudQuantity.ValueChanged += nudQuantity_ValueChanged;
            // 
            // comboProducts
            // 
            comboProducts.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboProducts.AutoCompleteSource = AutoCompleteSource.ListItems;
            comboProducts.FormattingEnabled = true;
            comboProducts.Location = new Point(166, 246);
            comboProducts.Name = "comboProducts";
            comboProducts.Size = new Size(222, 28);
            comboProducts.TabIndex = 71;
            comboProducts.SelectedIndexChanged += comboProducts_SelectedIndexChanged;
            // 
            // comboCustomer
            // 
            comboCustomer.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboCustomer.AutoCompleteSource = AutoCompleteSource.ListItems;
            comboCustomer.FormattingEnabled = true;
            comboCustomer.Location = new Point(166, 67);
            comboCustomer.Name = "comboCustomer";
            comboCustomer.Size = new Size(293, 28);
            comboCustomer.TabIndex = 72;
            comboCustomer.SelectedIndexChanged += comboCustomer_SelectedIndexChanged;
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Segoe UI", 9F);
            lblTotal.ForeColor = SystemColors.ControlLightLight;
            lblTotal.Location = new Point(166, 416);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(84, 20);
            lblTotal.TabIndex = 73;
            lblTotal.Text = "Total: 0.00$";
            // 
            // lblEstimatedDeliveryDate
            // 
            lblEstimatedDeliveryDate.AutoSize = true;
            lblEstimatedDeliveryDate.Font = new Font("Segoe UI", 10F);
            lblEstimatedDeliveryDate.ForeColor = SystemColors.ControlLightLight;
            lblEstimatedDeliveryDate.Location = new Point(13, 157);
            lblEstimatedDeliveryDate.Name = "lblEstimatedDeliveryDate";
            lblEstimatedDeliveryDate.Size = new Size(150, 23);
            lblEstimatedDeliveryDate.TabIndex = 74;
            lblEstimatedDeliveryDate.Text = "Estimated Delivery";
            // 
            // dtpEstimatedDeliveryDate
            // 
            dtpEstimatedDeliveryDate.CustomFormat = "dd/MM/yyyy";
            dtpEstimatedDeliveryDate.Format = DateTimePickerFormat.Custom;
            dtpEstimatedDeliveryDate.Location = new Point(166, 157);
            dtpEstimatedDeliveryDate.MinDate = new DateTime(2026, 1, 1, 0, 0, 0, 0);
            dtpEstimatedDeliveryDate.Name = "dtpEstimatedDeliveryDate";
            dtpEstimatedDeliveryDate.Size = new Size(293, 27);
            dtpEstimatedDeliveryDate.TabIndex = 75;
            dtpEstimatedDeliveryDate.Value = new DateTime(2026, 1, 2, 0, 0, 0, 0);
            // 
            // lblItemProductRequired
            // 
            lblItemProductRequired.AutoSize = true;
            lblItemProductRequired.Font = new Font("Segoe UI", 12F);
            lblItemProductRequired.ForeColor = Color.Gold;
            lblItemProductRequired.Location = new Point(90, 245);
            lblItemProductRequired.Name = "lblItemProductRequired";
            lblItemProductRequired.Size = new Size(20, 28);
            lblItemProductRequired.TabIndex = 77;
            lblItemProductRequired.Text = "*";
            // 
            // lblEstimatedDeliveryRequired
            // 
            lblEstimatedDeliveryRequired.AutoSize = true;
            lblEstimatedDeliveryRequired.Font = new Font("Segoe UI", 12F);
            lblEstimatedDeliveryRequired.ForeColor = Color.Gold;
            lblEstimatedDeliveryRequired.Location = new Point(0, 157);
            lblEstimatedDeliveryRequired.Name = "lblEstimatedDeliveryRequired";
            lblEstimatedDeliveryRequired.Size = new Size(20, 28);
            lblEstimatedDeliveryRequired.TabIndex = 79;
            lblEstimatedDeliveryRequired.Text = "*";
            // 
            // lblStatusRequired
            // 
            lblStatusRequired.AutoSize = true;
            lblStatusRequired.Font = new Font("Segoe UI", 12F);
            lblStatusRequired.ForeColor = Color.Gold;
            lblStatusRequired.Location = new Point(93, 112);
            lblStatusRequired.Name = "lblStatusRequired";
            lblStatusRequired.Size = new Size(20, 28);
            lblStatusRequired.TabIndex = 80;
            lblStatusRequired.Text = "*";
            // 
            // lblCustomerRequired
            // 
            lblCustomerRequired.AutoSize = true;
            lblCustomerRequired.Font = new Font("Segoe UI", 12F);
            lblCustomerRequired.ForeColor = Color.Gold;
            lblCustomerRequired.Location = new Point(65, 67);
            lblCustomerRequired.Name = "lblCustomerRequired";
            lblCustomerRequired.Size = new Size(20, 28);
            lblCustomerRequired.TabIndex = 81;
            lblCustomerRequired.Text = "*";
            // 
            // lblOrderItems
            // 
            lblOrderItems.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblOrderItems.ForeColor = SystemColors.ButtonHighlight;
            lblOrderItems.Location = new Point(394, 246);
            lblOrderItems.Name = "lblOrderItems";
            lblOrderItems.Size = new Size(65, 56);
            lblOrderItems.TabIndex = 82;
            lblOrderItems.Text = "Order Items";
            lblOrderItems.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblItemQuantityRequired
            // 
            lblItemQuantityRequired.AutoSize = true;
            lblItemQuantityRequired.Font = new Font("Segoe UI", 12F);
            lblItemQuantityRequired.ForeColor = Color.Gold;
            lblItemQuantityRequired.Location = new Point(85, 278);
            lblItemQuantityRequired.Name = "lblItemQuantityRequired";
            lblItemQuantityRequired.Size = new Size(20, 28);
            lblItemQuantityRequired.TabIndex = 83;
            lblItemQuantityRequired.Text = "*";
            // 
            // lblEmptyOrderItems
            // 
            lblEmptyOrderItems.Anchor = AnchorStyles.None;
            lblEmptyOrderItems.BackColor = SystemColors.Window;
            lblEmptyOrderItems.Font = new Font("Segoe UI", 9F);
            lblEmptyOrderItems.ForeColor = Color.Teal;
            lblEmptyOrderItems.Location = new Point(204, 355);
            lblEmptyOrderItems.Name = "lblEmptyOrderItems";
            lblEmptyOrderItems.RightToLeft = RightToLeft.No;
            lblEmptyOrderItems.Size = new Size(224, 40);
            lblEmptyOrderItems.TabIndex = 84;
            lblEmptyOrderItems.Text = "There are no order items yet.\nPlease add at least one item to the order.";
            lblEmptyOrderItems.TextAlign = ContentAlignment.MiddleCenter;
            lblEmptyOrderItems.Visible = false;
            // 
            // btnAdd
            // 
            btnAdd.Enabled = false;
            btnAdd.FlatStyle = FlatStyle.System;
            btnAdd.Location = new Point(81, 323);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(82, 29);
            btnAdd.TabIndex = 85;
            btnAdd.Text = "Add item";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS Reference Sans Serif", 8F);
            label1.ForeColor = Color.PaleTurquoise;
            label1.Location = new Point(166, 436);
            label1.Name = "label1";
            label1.Size = new Size(326, 54);
            label1.TabIndex = 86;
            label1.Text = "Double-click an item to change quantity\r\nand Click outside the cell to confirm changes.\r\n\r\n";
            // 
            // FormOrderInfo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(490, 575);
            Controls.Add(lblMsg);
            Controls.Add(label1);
            Controls.Add(btnAdd);
            Controls.Add(lblEmptyOrderItems);
            Controls.Add(lblQuantity);
            Controls.Add(lblProduct);
            Controls.Add(lblEstimatedDeliveryDate);
            Controls.Add(lblStatus);
            Controls.Add(lblCustomer);
            Controls.Add(lblItemQuantityRequired);
            Controls.Add(lblOrderItems);
            Controls.Add(lblCustomerRequired);
            Controls.Add(lblStatusRequired);
            Controls.Add(lblEstimatedDeliveryRequired);
            Controls.Add(lblItemProductRequired);
            Controls.Add(dtpEstimatedDeliveryDate);
            Controls.Add(lblTotal);
            Controls.Add(comboCustomer);
            Controls.Add(comboProducts);
            Controls.Add(nudQuantity);
            Controls.Add(btnDelete);
            Controls.Add(dgvOrderItems);
            Controls.Add(comboStatus);
            Controls.Add(tbxDescription);
            Controls.Add(lblDescription);
            Controls.Add(tbxID);
            Controls.Add(lblID);
            Controls.Add(btnCancel);
            Controls.Add(btnConfirm);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FormOrderInfo";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormOrderInfo";
            Load += FormOrderInfo_Load;
            ((System.ComponentModel.ISupportInitialize)dgvOrderItems).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblMsg;
        private TextBox tbxID;
        private Label lblID;
        private Button btnCancel;
        private Button btnConfirm;
        private Label lblCustomer;
        private TextBox tbxDescription;
        private Label lblDescription;
        private Label lblStatus;
        private ComboBox comboStatus;
        private DataGridView dgvOrderItems;
        private Button btnDelete;
        private Label lblQuantity;
        private TextBox tbxProductID;
        private Label lblProduct;
        private NumericUpDown nudQuantity;
        private ComboBox comboProducts;
        private ComboBox comboCustomer;
        private Label lblTotal;
        private Label lblEstimatedDeliveryDate;
        private DateTimePicker dtpEstimatedDeliveryDate;
        private Label lblItemProductRequired;
        private Label lblEstimatedDeliveryRequired;
        private Label lblStatusRequired;
        private Label lblCustomerRequired;
        private Label lblOrderItems;
        private Label lblItemQuantityRequired;
        private Label lblEmptyOrderItems;
        private Button btnAdd;
        private Label label1;
    }
}