﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Inventory_Management_System
{
    public class MonthlySalesSummary
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public string DisplayMonth =>
    $"{Month:D2}/{Year}";

        public int DeliveredOrdersCount { get; set; }
        public decimal DeliveredOrdersTotal { get; set; }

        public int UndeliveredOrdersCount { get; set; }
        public decimal UndeliveredOrdersTotal { get; set; }

        public int CancelledOrdersCount { get; set; }



        public static List<MonthlySalesSummary> BuildMonthlySalesSummary()
        {
            IEnumerable<Order> orders = FormOrders.Orders;

            Dictionary<(int Year, int Month), MonthlySalesSummary> result =
                new Dictionary<(int, int), MonthlySalesSummary>();

            foreach (Order order in orders)
            {
                int year = order.CreatedDate.Year;
                int month = order.CreatedDate.Month;

                var key = (year, month);

                if (!result.ContainsKey(key))
                {
                    result[key] = new MonthlySalesSummary //creat the class and asign the properties
                    {
                        Year = year,
                        Month = month
                    };
                }

                MonthlySalesSummary summary = result[key]; //read the val using the key

                if (order.Status == "Delivered")
                {
                    summary.DeliveredOrdersCount++;
                    summary.DeliveredOrdersTotal += order.TotalPrice;
                }
                else if (order.Status == "Cancelled")
                {
                    summary.CancelledOrdersCount++;
                }
                else
                {
                    summary.UndeliveredOrdersCount++;
                    summary.UndeliveredOrdersTotal += order.TotalPrice;
                }
            }

            return result.Values
                         .OrderBy(s => s.Year)
                         .ThenBy(s => s.Month)
                         .ToList();
        }
    }


}
