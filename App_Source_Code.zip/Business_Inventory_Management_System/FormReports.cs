﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormReports : Form
    {
        public FormReports()
        {
            InitializeComponent();
        }

        private void FormReports_Load(object sender, EventArgs e)
        {
            //
            dgvMonthlySummary.DataSource = MonthlySalesSummary.BuildMonthlySalesSummary();
            dgvMonthlySummary.Columns["Year"].Visible = false;
            dgvMonthlySummary.Columns["Month"].Visible = false;
            dgvMonthlySummary.Columns["DisplayMonth"].HeaderText = "Month";
            dgvMonthlySummary.Columns["DeliveredOrdersCount"].HeaderText = "Delivered Orders";
            dgvMonthlySummary.Columns["DeliveredOrdersTotal"].HeaderText = "Deliverd Orders Profit ($)";
            dgvMonthlySummary.Columns["UndeliveredOrdersCount"].HeaderText = "Undelivered Orders";
            dgvMonthlySummary.Columns["UndeliveredOrdersTotal"].HeaderText = "Undeliverd Orders Profit ($)";
            dgvMonthlySummary.Columns["CancelledOrdersCount"].HeaderText = "Cancelled Orders";
            if (dgvMonthlySummary.Rows.Count > 0)
                lblNoMonthlySummary.Visible = false;
            else
                lblNoMonthlySummary.Visible = true;
            //
            //

            //
            //
            dgvBestSellingProducts.DataSource = BestSellingProduct.BuildBestSellingProducts();
            dgvBestSellingProducts.Columns["Product"].Visible = false;
            dgvBestSellingProducts.Columns["DisplayText"].HeaderText = "Product";
            dgvBestSellingProducts.Columns["TotalSoldQuantity"].HeaderText = "Total Sold Pecies";
            if(dgvBestSellingProducts.Rows.Count > 0)
                lblNoBestSellingProducts.Visible = false;
            else
                lblNoBestSellingProducts.Visible = true;
            //
            //


            //
            //
            dgvMostActiveCustomers.DataSource = ActiveCustomerSummary.BuildMostActiveCustomers();
            dgvMostActiveCustomers.Columns["Customer"].Visible = false;
            dgvMostActiveCustomers.Columns["OrdersCount"].HeaderText = "Total Number Of Orders";
            dgvMostActiveCustomers.Columns["TotalSpent"].HeaderText = "Total Spent ($)";
            if (dgvMostActiveCustomers.Rows.Count > 0)
                lblNoActiveCustomers.Visible = false;
            else
                lblNoActiveCustomers.Visible = true;
            //
            //


            //
            //
            dgvLowStockProducts.DataSource = LowStockProductSummary();
            dgvLowStockProducts.Columns["ID"].Visible = false;
            dgvLowStockProducts.Columns["DisplayText"].Visible = false;
            dgvLowStockProducts.Columns["DisplayCode"].HeaderText = "ID";
            dgvLowStockProducts.Columns["Name"].HeaderText = "Product Name";
            dgvLowStockProducts.Columns["Price"].HeaderText = "Price ($)";
            if(dgvLowStockProducts.Rows.Count > 0)
                lblNoLowStockProducts.Visible = false;
            else
                lblNoLowStockProducts.Visible = true;
            //
            //

        }

        private List<Product> LowStockProductSummary()
        {
            var products = FormProducts.Products;

            int count = products.Count;
            if (count == 0)
                return new List<Product>();

            int stockTotal = 0;
            foreach (var p in products)
            {
                stockTotal += p.StockQuantity;
            }

            double lowStocklimit = ((double)stockTotal / count) * 0.5;

            List<Product> lowStockProducts = new();
            foreach (var p in products)
            {
                if (p.StockQuantity < lowStocklimit)
                    lowStockProducts.Add(p);
            }

            return lowStockProducts;
        }
    }
}
