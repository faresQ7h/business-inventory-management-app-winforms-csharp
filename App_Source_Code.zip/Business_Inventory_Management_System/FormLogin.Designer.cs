﻿namespace Business_Inventory_Management_System
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbxBusinessesList = new ListBox();
            lblMyBusinessList = new Label();
            lblPassword = new Label();
            tbxPassword = new TextBox();
            btnLogIn = new Button();
            btnCancel = new Button();
            panelListBox = new Panel();
            lblEmptyBussinssList = new Label();
            btnShowOrHidePass = new Button();
            lblPasswordWrong = new Label();
            btnDelete = new Button();
            panelListBox.SuspendLayout();
            SuspendLayout();
            // 
            // lbxBusinessesList
            // 
            lbxBusinessesList.BackColor = Color.Gainsboro;
            lbxBusinessesList.BorderStyle = BorderStyle.None;
            lbxBusinessesList.Dock = DockStyle.Fill;
            lbxBusinessesList.Font = new Font("Microsoft YaHei UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbxBusinessesList.ForeColor = SystemColors.ActiveCaptionText;
            lbxBusinessesList.FormattingEnabled = true;
            lbxBusinessesList.ItemHeight = 24;
            lbxBusinessesList.Location = new Point(0, 0);
            lbxBusinessesList.Name = "lbxBusinessesList";
            lbxBusinessesList.Size = new Size(398, 193);
            lbxBusinessesList.TabIndex = 0;
            lbxBusinessesList.SelectedIndexChanged += lbxBusinessesList_SelectedIndexChanged;
            // 
            // lblMyBusinessList
            // 
            lblMyBusinessList.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblMyBusinessList.ForeColor = SystemColors.ButtonHighlight;
            lblMyBusinessList.Location = new Point(5, 17);
            lblMyBusinessList.Name = "lblMyBusinessList";
            lblMyBusinessList.Size = new Size(219, 32);
            lblMyBusinessList.TabIndex = 1;
            lblMyBusinessList.Text = "My Business List";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI", 10F);
            lblPassword.ForeColor = SystemColors.ControlLightLight;
            lblPassword.Location = new Point(47, 265);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(80, 23);
            lblPassword.TabIndex = 2;
            lblPassword.Text = "Password";
            // 
            // tbxPassword
            // 
            tbxPassword.BackColor = Color.DarkGray;
            tbxPassword.BorderStyle = BorderStyle.FixedSingle;
            tbxPassword.Enabled = false;
            tbxPassword.Font = new Font("Segoe UI", 9F);
            tbxPassword.Location = new Point(124, 264);
            tbxPassword.Name = "tbxPassword";
            tbxPassword.PasswordChar = '*';
            tbxPassword.PlaceholderText = "Enter Pasword";
            tbxPassword.Size = new Size(217, 27);
            tbxPassword.TabIndex = 3;
            tbxPassword.TextChanged += tbxPassword_TextChanged;
            // 
            // btnLogIn
            // 
            btnLogIn.Anchor = AnchorStyles.None;
            btnLogIn.BackColor = Color.DarkSlateGray;
            btnLogIn.Enabled = false;
            btnLogIn.FlatAppearance.BorderColor = Color.Black;
            btnLogIn.FlatStyle = FlatStyle.Flat;
            btnLogIn.ForeColor = Color.Black;
            btnLogIn.Location = new Point(57, 333);
            btnLogIn.Name = "btnLogIn";
            btnLogIn.Size = new Size(157, 37);
            btnLogIn.TabIndex = 4;
            btnLogIn.Text = "Log in";
            btnLogIn.UseVisualStyleBackColor = false;
            btnLogIn.Click += btnLogIn_Click;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.None;
            btnCancel.Location = new Point(57, 385);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(330, 37);
            btnCancel.TabIndex = 5;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // panelListBox
            // 
            panelListBox.BorderStyle = BorderStyle.FixedSingle;
            panelListBox.Controls.Add(lblEmptyBussinssList);
            panelListBox.Controls.Add(lbxBusinessesList);
            panelListBox.Location = new Point(19, 52);
            panelListBox.Name = "panelListBox";
            panelListBox.Size = new Size(400, 195);
            panelListBox.TabIndex = 6;
            // 
            // lblEmptyBussinssList
            // 
            lblEmptyBussinssList.AutoSize = true;
            lblEmptyBussinssList.BackColor = Color.Gainsboro;
            lblEmptyBussinssList.Font = new Font("Segoe UI", 11F);
            lblEmptyBussinssList.ForeColor = Color.Teal;
            lblEmptyBussinssList.Location = new Point(30, 60);
            lblEmptyBussinssList.Name = "lblEmptyBussinssList";
            lblEmptyBussinssList.Size = new Size(336, 50);
            lblEmptyBussinssList.TabIndex = 10;
            lblEmptyBussinssList.Text = "You don't have any business inventory.\nPleas creat new one.";
            lblEmptyBussinssList.TextAlign = ContentAlignment.MiddleCenter;
            lblEmptyBussinssList.Visible = false;
            // 
            // btnShowOrHidePass
            // 
            btnShowOrHidePass.BackColor = Color.DarkGray;
            btnShowOrHidePass.Enabled = false;
            btnShowOrHidePass.FlatAppearance.BorderSize = 0;
            btnShowOrHidePass.FlatStyle = FlatStyle.Flat;
            btnShowOrHidePass.Image = Properties.Resources.showPasswordIcon;
            btnShowOrHidePass.Location = new Point(347, 265);
            btnShowOrHidePass.Name = "btnShowOrHidePass";
            btnShowOrHidePass.Size = new Size(30, 25);
            btnShowOrHidePass.TabIndex = 7;
            btnShowOrHidePass.UseVisualStyleBackColor = false;
            btnShowOrHidePass.Click += btnShowOrHidePass_Click;
            // 
            // lblPasswordWrong
            // 
            lblPasswordWrong.AutoSize = true;
            lblPasswordWrong.Font = new Font("Segoe UI", 8F);
            lblPasswordWrong.ForeColor = Color.Gold;
            lblPasswordWrong.Location = new Point(158, 293);
            lblPasswordWrong.Name = "lblPasswordWrong";
            lblPasswordWrong.Size = new Size(129, 19);
            lblPasswordWrong.TabIndex = 8;
            lblPasswordWrong.Text = "Incorrect password!";
            lblPasswordWrong.Visible = false;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.None;
            btnDelete.BackColor = Color.LightGray;
            btnDelete.Enabled = false;
            btnDelete.FlatAppearance.BorderColor = Color.Black;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.ForeColor = SystemColors.ControlDark;
            btnDelete.Location = new Point(230, 333);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(157, 37);
            btnDelete.TabIndex = 9;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(438, 445);
            Controls.Add(btnDelete);
            Controls.Add(lblPasswordWrong);
            Controls.Add(btnShowOrHidePass);
            Controls.Add(panelListBox);
            Controls.Add(btnCancel);
            Controls.Add(btnLogIn);
            Controls.Add(tbxPassword);
            Controls.Add(lblPassword);
            Controls.Add(lblMyBusinessList);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormLogin";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormLogin";
            Load += FormLogin_Load;
            panelListBox.ResumeLayout(false);
            panelListBox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lbxBusinessesList;
        private Label lblMyBusinessList;
        private Label lblPassword;
        private TextBox tbxPassword;
        private Button btnLogIn;
        private Button btnCancel;
        private Panel panelListBox;
        private Button btnShowOrHidePass;
        private Label lblPasswordWrong;
        private Button btnDelete;
        private Label lblEmptyBussinssList;
    }
}