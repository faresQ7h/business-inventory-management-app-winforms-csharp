namespace Business_Inventory_Management_System
{
    public partial class FormMain : Form
    {
        public bool IsLogout { get; set; } = false;

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            lblBusinessName.Text = Helpers.SelectedBusinessName;
            Helpers.LoadFormIntoPanel(new FormHome(), panelSectionContent);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Helpers.LoadFormIntoPanel(new FormHome(), panelSectionContent);
            HighlightMenuButton(btnHome);
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            Helpers.LoadFormIntoPanel(new FormProducts(), panelSectionContent);
            HighlightMenuButton(btnProducts);
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            Helpers.LoadFormIntoPanel(new FormCustomers(), panelSectionContent);
            HighlightMenuButton(btnCustomers);
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            Helpers.LoadFormIntoPanel(new FormOrders(), panelSectionContent);
            HighlightMenuButton(btnOrders);
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            Helpers.LoadFormIntoPanel(new FormReports(), panelSectionContent);
            HighlightMenuButton(btnReports);
        }

        private void brnChangePassword_Click(object sender, EventArgs e)
        {
            Helpers.LoadFormIntoPanel(new FormChangePassword(), panelSectionContent);
            HighlightMenuButton(brnChangePassword);
        }

        private void HighlightMenuButton(Button selectedButton)
        {
            foreach (Control ctrl in panelNavigation.Controls)
            {
                if (ctrl is Button btn && btn.Text != " Log out")
                {
                    btn.BackColor = Color.CadetBlue;
                }
            }

            selectedButton.BackColor = Color.Teal;

            lblSectionTitle.Text = selectedButton.Text.Trim();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            IsLogout = true;
            this.Close();
        }

        private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Helpers.SaveBindingListToJson<Product>(FormProducts.Products, "Products.json");
            Helpers.SaveBindingListToJson<Customer>(FormCustomers.Customers, "Customers.json");
            Helpers.SaveBindingListToJson<Order>(FormOrders.Orders, "Orders.json");
        }
    }
}
