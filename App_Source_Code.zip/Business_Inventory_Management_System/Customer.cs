﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Inventory_Management_System
{
    public class Customer : INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler? PropertyChanged;
        public long ID { get; set; }
        public string DisplayCode => $"COS-{ID}";
        public string DisplayText => $"{DisplayCode} | {FirstName} | {LastName} | {Phone} | ({Email})";

        private string _firstName;
        public string FirstName { get => _firstName;
            set
            {
                if (_firstName == value) return;
                _firstName = value;
                OnPropertyChanged(nameof(FirstName));
            } 
        }

        private string _lastName;
        public string LastName
        {
            get => _lastName;
            set
            {
                if (_lastName == value) return;
                _lastName = value;
                OnPropertyChanged(nameof(LastName));
            }
        }

        private string _phone;
        public string Phone
        {
            get => _phone;
            set
            {
                if (_phone == value) return;
                _phone = value;
                OnPropertyChanged(nameof(Phone));
            }
        }

        private string _email;
        public string Email
        {
            get => _email;
            set
            {
                if (_email == value) return;
                _email = value;
                OnPropertyChanged(nameof(Email));
            }
        }

        private string _address;
        public string Address
        {
            get => _address;
            set
            {
                if (_address == value) return;
                _address = value;
                OnPropertyChanged(nameof(Address));
            }
        }

        private static long IDSeed = 0;

        public Customer() { }
        public Customer(string firstname, string lastname, string phone, string email, string address = "") 
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.Phone = phone;
            this.Email = email;
            this.Address = address;
            this.ID = ++IDSeed;
        }

        public static void InitializeIDSeed(BindingList<Customer> clist)
        {
            if (clist == null)
                return;
            IDSeed = 0;
            foreach (Customer c in clist)
            {
                if (c.ID > IDSeed)
                    IDSeed = c.ID;
            }

        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
