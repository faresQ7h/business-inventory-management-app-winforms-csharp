﻿namespace Business_Inventory_Management_System
{
    partial class FormProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            dgvProducts = new DataGridView();
            lblEmptyProductsList = new Label();
            panelOptions = new Panel();
            btnReset = new Button();
            btnSearch = new Button();
            btnDelete = new Button();
            btnEdit = new Button();
            btnAdd = new Button();
            lblNoResults = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvProducts).BeginInit();
            panelOptions.SuspendLayout();
            SuspendLayout();
            // 
            // dgvProducts
            // 
            dgvProducts.AllowUserToAddRows = false;
            dgvProducts.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvProducts.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvProducts.DefaultCellStyle = dataGridViewCellStyle2;
            dgvProducts.Location = new Point(12, 12);
            dgvProducts.Name = "dgvProducts";
            dgvProducts.ReadOnly = true;
            dgvProducts.RowHeadersVisible = false;
            dgvProducts.RowHeadersWidth = 51;
            dgvProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProducts.Size = new Size(600, 584);
            dgvProducts.TabIndex = 1;
            dgvProducts.SelectionChanged += dgvProducts_SelectionChanged;
            // 
            // lblEmptyProductsList
            // 
            lblEmptyProductsList.Anchor = AnchorStyles.None;
            lblEmptyProductsList.BackColor = Color.Gainsboro;
            lblEmptyProductsList.Font = new Font("Segoe UI", 11F);
            lblEmptyProductsList.ForeColor = Color.Teal;
            lblEmptyProductsList.Location = new Point(156, 250);
            lblEmptyProductsList.Name = "lblEmptyProductsList";
            lblEmptyProductsList.Size = new Size(321, 64);
            lblEmptyProductsList.TabIndex = 4;
            lblEmptyProductsList.Text = "There are no products in the list.\nPlease add new products to the list.";
            lblEmptyProductsList.Visible = false;
            // 
            // panelOptions
            // 
            panelOptions.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            panelOptions.Controls.Add(btnReset);
            panelOptions.Controls.Add(btnSearch);
            panelOptions.Controls.Add(btnDelete);
            panelOptions.Controls.Add(btnEdit);
            panelOptions.Controls.Add(btnAdd);
            panelOptions.Location = new Point(618, 118);
            panelOptions.Name = "panelOptions";
            panelOptions.Size = new Size(148, 478);
            panelOptions.TabIndex = 7;
            // 
            // btnReset
            // 
            btnReset.Font = new Font("Segoe UI", 11F);
            btnReset.ForeColor = Color.Black;
            btnReset.Location = new Point(0, 284);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(148, 53);
            btnReset.TabIndex = 4;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSearch.BackColor = Color.LightSeaGreen;
            btnSearch.FlatAppearance.BorderColor = Color.Black;
            btnSearch.FlatStyle = FlatStyle.Popup;
            btnSearch.Font = new Font("Segoe UI", 11F);
            btnSearch.Location = new Point(0, 224);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(148, 53);
            btnSearch.TabIndex = 3;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnDelete.BackColor = Color.DarkSlateGray;
            btnDelete.Enabled = false;
            btnDelete.FlatAppearance.BorderColor = Color.Black;
            btnDelete.FlatStyle = FlatStyle.Popup;
            btnDelete.Font = new Font("Segoe UI", 11F);
            btnDelete.Location = new Point(0, 120);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(148, 53);
            btnDelete.TabIndex = 2;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnEdit
            // 
            btnEdit.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnEdit.BackColor = Color.DarkSlateGray;
            btnEdit.Enabled = false;
            btnEdit.FlatAppearance.BorderColor = Color.Black;
            btnEdit.FlatStyle = FlatStyle.Popup;
            btnEdit.Font = new Font("Segoe UI", 11F);
            btnEdit.Location = new Point(0, 60);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(148, 53);
            btnEdit.TabIndex = 1;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.LightSeaGreen;
            btnAdd.Dock = DockStyle.Top;
            btnAdd.FlatAppearance.BorderColor = Color.Black;
            btnAdd.FlatStyle = FlatStyle.Popup;
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.Location = new Point(0, 0);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(148, 53);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // lblNoResults
            // 
            lblNoResults.Anchor = AnchorStyles.None;
            lblNoResults.BackColor = Color.Gainsboro;
            lblNoResults.Font = new Font("Segoe UI", 11F);
            lblNoResults.ForeColor = Color.Teal;
            lblNoResults.Location = new Point(172, 263);
            lblNoResults.Name = "lblNoResults";
            lblNoResults.Size = new Size(263, 28);
            lblNoResults.TabIndex = 8;
            lblNoResults.Text = "There are no matching results";
            lblNoResults.Visible = false;
            // 
            // FormProducts
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(772, 608);
            Controls.Add(lblNoResults);
            Controls.Add(panelOptions);
            Controls.Add(lblEmptyProductsList);
            Controls.Add(dgvProducts);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormProducts";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormProducts";
            FormClosing += FormProducts_FormClosing;
            Load += FormProducts_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProducts).EndInit();
            panelOptions.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private DataGridView dgvProducts;
        private Label lblEmptyProductsList;
        private Panel panelOptions;
        private Button btnReset;
        private Button btnSearch;
        private Button btnDelete;
        private Button btnEdit;
        private Button btnAdd;
        private Label lblNoResults;
    }
}