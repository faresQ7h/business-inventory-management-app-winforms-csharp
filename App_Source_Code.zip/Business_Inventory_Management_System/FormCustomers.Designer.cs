﻿namespace Business_Inventory_Management_System
{
    partial class FormCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            lblEmptyCustomersList = new Label();
            dgvCustomers = new DataGridView();
            panelOptions = new Panel();
            btnReset = new Button();
            btnSearch = new Button();
            btnDelete = new Button();
            btnEdit = new Button();
            btnAdd = new Button();
            lblNoResults = new Label();
            panelCustomers = new Panel();
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).BeginInit();
            panelOptions.SuspendLayout();
            panelCustomers.SuspendLayout();
            SuspendLayout();
            // 
            // lblEmptyCustomersList
            // 
            lblEmptyCustomersList.Anchor = AnchorStyles.None;
            lblEmptyCustomersList.BackColor = Color.Gainsboro;
            lblEmptyCustomersList.Font = new Font("Segoe UI", 11F);
            lblEmptyCustomersList.ForeColor = Color.Teal;
            lblEmptyCustomersList.Location = new Point(126, 232);
            lblEmptyCustomersList.Name = "lblEmptyCustomersList";
            lblEmptyCustomersList.Size = new Size(346, 81);
            lblEmptyCustomersList.TabIndex = 6;
            lblEmptyCustomersList.Text = "There are no customers yet.\nPlease add new customers to the list.";
            lblEmptyCustomersList.TextAlign = ContentAlignment.MiddleCenter;
            lblEmptyCustomersList.Visible = false;
            // 
            // dgvCustomers
            // 
            dgvCustomers.AllowUserToAddRows = false;
            dgvCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCustomers.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvCustomers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvCustomers.DefaultCellStyle = dataGridViewCellStyle2;
            dgvCustomers.Dock = DockStyle.Fill;
            dgvCustomers.Location = new Point(0, 0);
            dgvCustomers.Name = "dgvCustomers";
            dgvCustomers.ReadOnly = true;
            dgvCustomers.RowHeadersVisible = false;
            dgvCustomers.RowHeadersWidth = 51;
            dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomers.Size = new Size(602, 584);
            dgvCustomers.TabIndex = 5;
            dgvCustomers.SelectionChanged += dgvCustomers_SelectionChanged;
            // 
            // panelOptions
            // 
            panelOptions.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            panelOptions.Controls.Add(btnReset);
            panelOptions.Controls.Add(btnSearch);
            panelOptions.Controls.Add(btnDelete);
            panelOptions.Controls.Add(btnEdit);
            panelOptions.Controls.Add(btnAdd);
            panelOptions.Location = new Point(618, 118);
            panelOptions.Name = "panelOptions";
            panelOptions.Size = new Size(148, 478);
            panelOptions.TabIndex = 7;
            // 
            // btnReset
            // 
            btnReset.Font = new Font("Segoe UI", 11F);
            btnReset.ForeColor = Color.Black;
            btnReset.Location = new Point(0, 284);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(148, 53);
            btnReset.TabIndex = 6;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSearch.BackColor = Color.LightSeaGreen;
            btnSearch.FlatAppearance.BorderColor = Color.Black;
            btnSearch.FlatStyle = FlatStyle.Popup;
            btnSearch.Font = new Font("Segoe UI", 11F);
            btnSearch.Location = new Point(0, 224);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(148, 53);
            btnSearch.TabIndex = 5;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnDelete.BackColor = Color.DarkSlateGray;
            btnDelete.Enabled = false;
            btnDelete.FlatAppearance.BorderColor = Color.Black;
            btnDelete.FlatStyle = FlatStyle.Popup;
            btnDelete.Font = new Font("Segoe UI", 11F);
            btnDelete.Location = new Point(0, 120);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(148, 53);
            btnDelete.TabIndex = 2;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnEdit
            // 
            btnEdit.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnEdit.BackColor = Color.DarkSlateGray;
            btnEdit.Enabled = false;
            btnEdit.FlatAppearance.BorderColor = Color.Black;
            btnEdit.FlatStyle = FlatStyle.Popup;
            btnEdit.Font = new Font("Segoe UI", 11F);
            btnEdit.Location = new Point(0, 60);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(148, 53);
            btnEdit.TabIndex = 1;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.LightSeaGreen;
            btnAdd.Dock = DockStyle.Top;
            btnAdd.FlatAppearance.BorderColor = Color.Black;
            btnAdd.FlatStyle = FlatStyle.Popup;
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.Location = new Point(0, 0);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(148, 53);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // lblNoResults
            // 
            lblNoResults.BackColor = Color.Gainsboro;
            lblNoResults.Font = new Font("Segoe UI", 11F);
            lblNoResults.ForeColor = Color.Teal;
            lblNoResults.Location = new Point(135, 231);
            lblNoResults.Name = "lblNoResults";
            lblNoResults.Size = new Size(346, 81);
            lblNoResults.TabIndex = 9;
            lblNoResults.Text = "There are no matching results";
            lblNoResults.TextAlign = ContentAlignment.MiddleCenter;
            lblNoResults.Visible = false;
            // 
            // panelCustomers
            // 
            panelCustomers.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panelCustomers.Controls.Add(lblEmptyCustomersList);
            panelCustomers.Controls.Add(lblNoResults);
            panelCustomers.Controls.Add(dgvCustomers);
            panelCustomers.Location = new Point(10, 12);
            panelCustomers.Name = "panelCustomers";
            panelCustomers.Size = new Size(602, 584);
            panelCustomers.TabIndex = 10;
            // 
            // FormCustomers
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(772, 608);
            Controls.Add(panelCustomers);
            Controls.Add(panelOptions);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormCustomers";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormCustomers";
            FormClosed += FormCustomers_FormClosed;
            Load += FormCustomers_Load;
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).EndInit();
            panelOptions.ResumeLayout(false);
            panelCustomers.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Label lblEmptyCustomersList;
        private DataGridView dgvCustomers;
        private Panel panelOptions;
        private Button btnDelete;
        private Button btnEdit;
        private Button btnAdd;
        private Button btnReset;
        private Button btnSearch;
        private Label lblNoResults;
        private Panel panelCustomers;
    }
}