﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormCustomers : Form
    {
        public static long ID { get; set; }
        public static string FirstName { get; set; }
        public static string LastName { get; set; }
        public static string Phone { get; set; }
        public static string Email { get; set; }
        public static string Address { get; set; }

        public static BindingList<Customer> Customers =
            Helpers.LoadJsonToBindingList<Customer>("Customers.Json");

        public FormCustomers()
        {
            InitializeComponent();
            Customer.InitializeIDSeed(Customers);
        }

        private void FormCustomers_Load(object sender, EventArgs e)
        {
            dgvCustomers.DataSource = Customers;
            dgvCustomers.Columns["ID"].Visible = false;
            dgvCustomers.Columns["DisplayText"].Visible = false;
            dgvCustomers.Columns["DisplayCode"].HeaderText = "ID";
            dgvCustomers.Columns["FirstName"].HeaderText = "First Name";
            dgvCustomers.Columns["LastName"].HeaderText = "Last Name";
            UpdateLabelOnEmptyList();
            UpdateEditAndDeleteButtons();
            lblNoResults.Visible = false;
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            using FormCustomerInfo frm = new FormCustomerInfo('A'); //Add Mode
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;

            Customers.Add(new Customer(FirstName, LastName, Phone, Email, Address));
            UpdateLabelOnEmptyList();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Customer c = dgvCustomers.CurrentRow.DataBoundItem as Customer;
            using FormCustomerInfo frm = new FormCustomerInfo('E', c); //Edite mode
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;

            c.FirstName = FirstName;
            c.LastName = LastName;
            c.Phone = Phone;
            c.Email = Email;
            c.Address = Address;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
            $"Are you sure you want to delete Customer with ID({(dgvCustomers.CurrentRow.DataBoundItem as Customer).DisplayCode})?\n\nThis action cannot be undone.",
            "Confirm Delete",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes) return;

            Customer p = dgvCustomers.CurrentRow.DataBoundItem as Customer;
            Customers.Remove(p);

            if (dgvCustomers.DataSource is BindingList<Customer> currentList &&
            currentList != Customers) //delete is the list in the dgv is the temp by searching
            {
                currentList.Remove(p);
            }
            UpdateLabelOnEmptyList();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using FormCustomerInfo frm = new FormCustomerInfo('S'); //Search mode
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;


            BindingList<Customer> temp = new BindingList<Customer>();
            foreach (Customer c in Customers)
            {
                bool match = true;

                if (ID > 0 && c.ID != ID)
                    match = false;

                if (!string.IsNullOrWhiteSpace(FirstName) &&
                    !c.FirstName.Contains(FirstName, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (!string.IsNullOrWhiteSpace(LastName) &&
                    !c.LastName.Contains(LastName, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (!string.IsNullOrWhiteSpace(Phone) &&
                    !c.Phone.Contains(Phone, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (!string.IsNullOrWhiteSpace(Email) &&
                    !c.Phone.Contains(Phone, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (!string.IsNullOrWhiteSpace(Address) &&
                    !c.Phone.Contains(Phone, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (match)
                    temp.Add(c);
            }
            if (temp.Count == 0)
                lblNoResults.Visible = true;
            else lblNoResults.Visible = false;
            dgvCustomers.DataSource = temp;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {

        }

        private void dgvCustomers_SelectionChanged(object sender, EventArgs e)
        {
            UpdateEditAndDeleteButtons();
        }

        private void FormCustomers_FormClosed(object sender, FormClosedEventArgs e)
        {
            Helpers.SaveBindingListToJson<Customer>(Customers, "Customers.json");
        }

        void UpdateLabelOnEmptyList()
        {
            if (Customers.Count == 0)
                lblEmptyCustomersList.Visible = true;
            else
                lblEmptyCustomersList.Visible = false;
        }

        void UpdateEditAndDeleteButtons()
        {
            if (dgvCustomers.CurrentRow != null)
            {
                Helpers.AvtivateButton(btnEdit, Color.LightSeaGreen);
                Helpers.AvtivateButton(btnDelete, Color.LightSeaGreen);
                return;
            }
            Helpers.DeavtivateButton(btnEdit, Color.DarkSlateGray);
            Helpers.DeavtivateButton(btnDelete, Color.DarkSlateGray);
        }


    }
}
