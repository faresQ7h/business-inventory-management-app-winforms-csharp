﻿namespace Business_Inventory_Management_System
{
    partial class FormCreate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreate = new Button();
            btnCancel = new Button();
            lblNewName = new Label();
            lblNewPassword = new Label();
            tbxNewBusinessName = new TextBox();
            tbxNewPassword = new TextBox();
            lblConfirmPassword = new Label();
            tbxConfirmPassword = new TextBox();
            btnShowOrHideNewPass = new Button();
            btnShowOrHideConfirmPass = new Button();
            lblPasswordNotMatch = new Label();
            lblImportantMessage = new Label();
            lblSuccessfulCreate = new Label();
            SuspendLayout();
            // 
            // btnCreate
            // 
            btnCreate.BackColor = Color.DarkSlateGray;
            btnCreate.Enabled = false;
            btnCreate.FlatAppearance.BorderColor = Color.Black;
            btnCreate.FlatStyle = FlatStyle.Flat;
            btnCreate.ForeColor = Color.Black;
            btnCreate.Location = new Point(130, 332);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(167, 37);
            btnCreate.TabIndex = 0;
            btnCreate.Text = "Create";
            btnCreate.UseVisualStyleBackColor = false;
            btnCreate.Click += btnCreate_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(130, 385);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(167, 37);
            btnCancel.TabIndex = 1;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // lblNewName
            // 
            lblNewName.AutoSize = true;
            lblNewName.Font = new Font("Segoe UI", 10F);
            lblNewName.ForeColor = SystemColors.ControlLightLight;
            lblNewName.Location = new Point(20, 49);
            lblNewName.Name = "lblNewName";
            lblNewName.Size = new Size(125, 23);
            lblNewName.TabIndex = 2;
            lblNewName.Text = "Business Name";
            // 
            // lblNewPassword
            // 
            lblNewPassword.AutoSize = true;
            lblNewPassword.Font = new Font("Segoe UI", 10F);
            lblNewPassword.ForeColor = SystemColors.ControlLightLight;
            lblNewPassword.Location = new Point(65, 105);
            lblNewPassword.Name = "lblNewPassword";
            lblNewPassword.Size = new Size(80, 23);
            lblNewPassword.TabIndex = 3;
            lblNewPassword.Text = "Password";
            // 
            // tbxNewBusinessName
            // 
            tbxNewBusinessName.BorderStyle = BorderStyle.FixedSingle;
            tbxNewBusinessName.Font = new Font("Segoe UI", 9F);
            tbxNewBusinessName.Location = new Point(142, 49);
            tbxNewBusinessName.Name = "tbxNewBusinessName";
            tbxNewBusinessName.PlaceholderText = "Enter business name";
            tbxNewBusinessName.Size = new Size(284, 27);
            tbxNewBusinessName.TabIndex = 4;
            tbxNewBusinessName.TextChanged += tbxNewBusinessName_TextChanged;
            // 
            // tbxNewPassword
            // 
            tbxNewPassword.BorderStyle = BorderStyle.FixedSingle;
            tbxNewPassword.Font = new Font("Segoe UI", 9F);
            tbxNewPassword.Location = new Point(142, 104);
            tbxNewPassword.Name = "tbxNewPassword";
            tbxNewPassword.PasswordChar = '*';
            tbxNewPassword.PlaceholderText = "Enter password";
            tbxNewPassword.Size = new Size(248, 27);
            tbxNewPassword.TabIndex = 5;
            tbxNewPassword.TextChanged += tbxNewPassword_TextChanged;
            // 
            // lblConfirmPassword
            // 
            lblConfirmPassword.AutoSize = true;
            lblConfirmPassword.Font = new Font("Segoe UI", 10F);
            lblConfirmPassword.ForeColor = SystemColors.ControlLightLight;
            lblConfirmPassword.Location = new Point(-1, 164);
            lblConfirmPassword.Name = "lblConfirmPassword";
            lblConfirmPassword.Size = new Size(146, 23);
            lblConfirmPassword.TabIndex = 6;
            lblConfirmPassword.Text = "Confirm Password";
            // 
            // tbxConfirmPassword
            // 
            tbxConfirmPassword.BackColor = Color.DarkGray;
            tbxConfirmPassword.BorderStyle = BorderStyle.FixedSingle;
            tbxConfirmPassword.Enabled = false;
            tbxConfirmPassword.Font = new Font("Segoe UI", 9F);
            tbxConfirmPassword.Location = new Point(142, 163);
            tbxConfirmPassword.Name = "tbxConfirmPassword";
            tbxConfirmPassword.PasswordChar = '*';
            tbxConfirmPassword.PlaceholderText = "Enter confirm password";
            tbxConfirmPassword.Size = new Size(248, 27);
            tbxConfirmPassword.TabIndex = 7;
            tbxConfirmPassword.TextChanged += tbxConfirmPassword_TextChanged;
            // 
            // btnShowOrHideNewPass
            // 
            btnShowOrHideNewPass.BackColor = Color.DarkGray;
            btnShowOrHideNewPass.FlatAppearance.BorderSize = 0;
            btnShowOrHideNewPass.FlatStyle = FlatStyle.Flat;
            btnShowOrHideNewPass.Image = Properties.Resources.showPasswordIcon;
            btnShowOrHideNewPass.Location = new Point(396, 105);
            btnShowOrHideNewPass.Name = "btnShowOrHideNewPass";
            btnShowOrHideNewPass.Size = new Size(30, 25);
            btnShowOrHideNewPass.TabIndex = 8;
            btnShowOrHideNewPass.UseVisualStyleBackColor = false;
            btnShowOrHideNewPass.Click += btnShowOrHideNewPass_Click;
            // 
            // btnShowOrHideConfirmPass
            // 
            btnShowOrHideConfirmPass.BackColor = Color.DarkGray;
            btnShowOrHideConfirmPass.Enabled = false;
            btnShowOrHideConfirmPass.FlatAppearance.BorderSize = 0;
            btnShowOrHideConfirmPass.FlatStyle = FlatStyle.Flat;
            btnShowOrHideConfirmPass.Image = Properties.Resources.showPasswordIcon;
            btnShowOrHideConfirmPass.Location = new Point(396, 164);
            btnShowOrHideConfirmPass.Name = "btnShowOrHideConfirmPass";
            btnShowOrHideConfirmPass.Size = new Size(30, 25);
            btnShowOrHideConfirmPass.TabIndex = 9;
            btnShowOrHideConfirmPass.UseVisualStyleBackColor = false;
            btnShowOrHideConfirmPass.Click += btnShowOrHideConfirmPass_Click;
            // 
            // lblPasswordNotMatch
            // 
            lblPasswordNotMatch.AutoSize = true;
            lblPasswordNotMatch.Font = new Font("Segoe UI", 8F);
            lblPasswordNotMatch.ForeColor = Color.Gold;
            lblPasswordNotMatch.Location = new Point(175, 194);
            lblPasswordNotMatch.Name = "lblPasswordNotMatch";
            lblPasswordNotMatch.Size = new Size(164, 19);
            lblPasswordNotMatch.TabIndex = 10;
            lblPasswordNotMatch.Text = "Passwords do not match!";
            lblPasswordNotMatch.Visible = false;
            // 
            // lblImportantMessage
            // 
            lblImportantMessage.BackColor = Color.Gray;
            lblImportantMessage.Font = new Font("MS Reference Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblImportantMessage.ForeColor = Color.PaleTurquoise;
            lblImportantMessage.Location = new Point(12, 223);
            lblImportantMessage.Name = "lblImportantMessage";
            lblImportantMessage.Size = new Size(407, 76);
            lblImportantMessage.TabIndex = 11;
            lblImportantMessage.Text = "Important: Please remember this password.\nFor security reasons, it cannot be recovered if forgotten.";
            // 
            // lblSuccessfulCreate
            // 
            lblSuccessfulCreate.BackColor = Color.Gray;
            lblSuccessfulCreate.Font = new Font("Segoe UI", 10F);
            lblSuccessfulCreate.ForeColor = Color.LawnGreen;
            lblSuccessfulCreate.Location = new Point(65, 299);
            lblSuccessfulCreate.Name = "lblSuccessfulCreate";
            lblSuccessfulCreate.Size = new Size(325, 25);
            lblSuccessfulCreate.TabIndex = 12;
            lblSuccessfulCreate.Text = "Your business was created successfully.";
            lblSuccessfulCreate.TextAlign = ContentAlignment.MiddleCenter;
            lblSuccessfulCreate.Visible = false;
            // 
            // FormCreate
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(438, 445);
            Controls.Add(lblSuccessfulCreate);
            Controls.Add(lblImportantMessage);
            Controls.Add(lblPasswordNotMatch);
            Controls.Add(btnShowOrHideConfirmPass);
            Controls.Add(btnShowOrHideNewPass);
            Controls.Add(tbxConfirmPassword);
            Controls.Add(lblConfirmPassword);
            Controls.Add(tbxNewPassword);
            Controls.Add(tbxNewBusinessName);
            Controls.Add(lblNewPassword);
            Controls.Add(lblNewName);
            Controls.Add(btnCancel);
            Controls.Add(btnCreate);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormCreate";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormCreate";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCreate;
        private Button btnCancel;
        private Label lblNewName;
        private Label lblNewPassword;
        private TextBox tbxNewBusinessName;
        private TextBox tbxNewPassword;
        private Label lblConfirmPassword;
        private TextBox tbxConfirmPassword;
        private Button btnShowOrHideNewPass;
        private Button btnShowOrHideConfirmPass;
        private Label lblPasswordNotMatch;
        private Label lblImportantMessage;
        private Label lblSuccessfulCreate;
    }
}