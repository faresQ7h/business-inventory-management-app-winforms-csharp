﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace Business_Inventory_Management_System
{
    public partial class FormHome : Form
    {
        public FormHome()
        {
            InitializeComponent();
        }
        private void FormHome_Load(object sender, EventArgs e)
        {
            //clock
            lblClock.Text = DateTime.Now.ToString("HH:mm");
            lblDate.Text = DateTime.Now.ToString("ddd dd MMMM");
            timerClock.Start();

            //load the Orders.Json and get some data
            string ordersDataPath = Path.Combine(Helpers.SelectedBusinessPath, "Orders.json");
            if (!File.Exists(ordersDataPath))
            {
                lblNoOrdersThisMonth.Visible = true;
                return;
            }

            //creat BindingList out from the List and fiilter data to show on home
            int thisMonthDeliveredCount;
            int thisMonthUndeliveredCount;
            decimal thisMonthProfit;
            BindingList<Order> ordersToDeliverThisMonth = ProcessOrdersForHome(
                out thisMonthDeliveredCount, 
                out thisMonthUndeliveredCount, 
                out thisMonthProfit);


            //load the data
            lblTotalProfit.Text = thisMonthProfit.ToString("F2") + " $";
            lblNumberOfDeliveredOrders.Text = thisMonthDeliveredCount.ToString();
            lblNumberOfUndeliveredOrders.Text = thisMonthUndeliveredCount.ToString();

            dgvUndeliveredOrders.DataSource = ordersToDeliverThisMonth;


            //Adjust columns:
            dgvUndeliveredOrders.AutoGenerateColumns = false;
            dgvUndeliveredOrders.Columns.Clear();

            dgvUndeliveredOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "ID",
                DataPropertyName = "DisplayCode",
                Name = "ID",
                ReadOnly = true,
                Width = 80
            });

            dgvUndeliveredOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Created On",
                DataPropertyName = "CreatedDate",
                DefaultCellStyle = new DataGridViewCellStyle //to make the date on the following format
                {
                    Format = "dd/MM/yyyy"
                }
            });

            dgvUndeliveredOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Customer",
                DataPropertyName = "DisplayCustomerText"
            });

            dgvUndeliveredOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Estimated Delivery",
                DataPropertyName = "EstimatedDeliveryDate",
                DefaultCellStyle = new DataGridViewCellStyle //to make the date on the following format
                {
                    Format = "dd/MM/yyyy"
                }
            });

            dgvUndeliveredOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Status",
                DataPropertyName = "Status"
            });

            dgvUndeliveredOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Total ($)",
                DataPropertyName = "TotalPrice"
            });


            if (ordersToDeliverThisMonth.Count == 0)
            {
                lblNoOrdersThisMonth.Visible = true;
            }
            else
            {
                lblNoOrdersThisMonth.Visible = false;
            }
        }

        private void timerClock_Tick(object sender, EventArgs e)
        {
            lblClock.Text = DateTime.Now.ToString("HH:mm");
            lblDate.Text = DateTime.Now.ToString("ddd dd MMMM");
        }

        private BindingList<Order> ProcessOrdersForHome(
            out int thisMonthDeliveredCount,
            out int thisMonthUndeliveredCount,
            out decimal thisMonthProfit)
        {
            thisMonthDeliveredCount = 0;
            thisMonthUndeliveredCount = 0;
            thisMonthProfit = 0;

            BindingList<Order> orders = FormOrders.Orders;
            BindingList<Order> thisMonthUndeliveredOrders = new BindingList<Order>();

            int currentMonth = DateTime.Today.Month;
            int currentYear = DateTime.Today.Year;

            foreach (Order order in orders)
            {
                if (order.EstimatedDeliveryDate.Month != currentMonth ||
                    order.EstimatedDeliveryDate.Year != currentYear)
                    continue;

                if (order.Status == "Delivered")
                {
                    thisMonthDeliveredCount++;
                    thisMonthProfit += order.TotalPrice;
                }
                else
                {
                    thisMonthUndeliveredCount++;
                    thisMonthUndeliveredOrders.Add(order);
                }
            }

            return thisMonthUndeliveredOrders;
        }
    }
}
