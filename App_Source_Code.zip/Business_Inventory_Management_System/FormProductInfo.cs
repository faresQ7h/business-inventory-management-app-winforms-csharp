﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormProductInfo : Form
    {
        //
        //
        //
        private char _Mode;// S = serech, E = edit, A = add
        private Product _SelectedProduct; 

        public FormProductInfo(char whichMode) //when Adding/Searching
        {
            InitializeComponent();
            this._Mode = whichMode;
        }

        public FormProductInfo(char whichMode, Product product) //when Editing
        {
            InitializeComponent();
            this._Mode = whichMode;
            this._SelectedProduct = product;
        }
        //
        //
        //

        private void FormProductInfo_Load(object sender, EventArgs e)
        {
            if (_Mode == 'S')
            {
                lblID.Visible = true;
                tbxID.Visible = true;

                lblNameRequired.Visible = false;
                lblPriceRequired.Visible = false;
                lblStockQuantityRequired.Visible = false;

                Helpers.AvtivateButton(btnConfirm, Color.LightSeaGreen);
                lblMsg.Visible = false;
                return;
            }

            lblMsg.Text = "Fields marked with (*) are required.";
            lblMsg.Visible = true;

            if(_Mode == 'E')
            {
                tbxName.Text = _SelectedProduct.Name;
                tbxCategory.Text = _SelectedProduct.Category;
                tbxDescription.Text = _SelectedProduct.Description;
                nudPrice.Value = _SelectedProduct.Price;
                nudStockQuantity.Value = _SelectedProduct.StockQuantity;
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (_Mode == 'S')
            {
                if (!string.IsNullOrWhiteSpace(tbxID.Text))
                {
                    if (!Helpers.IsValidIDInput(tbxID.Text, "PRO"))
                    {
                        tbxID.Clear();
                        lblMsg.Text = "Invalid ID format. Please enter a number or a code like PRO-123";
                        lblMsg.Visible = true;
                        return;
                    }
                    FormProducts.ID = Helpers.GetIDNumberOnly(tbxID.Text);
                }
                else
                {
                    FormProducts.ID = 0;
                }
                SendDataBackAndClose();
                return;
            }


            //in case of Add or Edite
            SendDataBackAndClose();
        }

        private void tbxName_TextChanged(object sender, EventArgs e)
        {
            if(_Mode != 'S')
                UpdateConfirmButton();
        }

        private void tbxCategory_TextChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void nudPrice_ValueChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void nudStockQuantity_ValueChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        void UpdateConfirmButton()
        {
            if(!string.IsNullOrEmpty(tbxName.Text) &&
                nudPrice.Value != 0 &&
                nudStockQuantity.Value != 0.00m)
                Helpers.AvtivateButton(btnConfirm, Color.LightSeaGreen);
            else
                Helpers.DeavtivateButton(btnConfirm, Color.DarkSlateGray);
        }

        void SendDataBackAndClose()
        {
            FormProducts.Name = (tbxName.Text ?? "").Trim();
            FormProducts.Category = (tbxCategory.Text ?? "").Trim();
            FormProducts.Price = nudPrice.Value == 0 ? 0 : nudPrice.Value;
            FormProducts.StockQuantity = (int)nudStockQuantity.Value == 0 ? 0 : (int)nudStockQuantity.Value;
            FormProducts.Description = (tbxDescription.Text ?? "").Trim();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
