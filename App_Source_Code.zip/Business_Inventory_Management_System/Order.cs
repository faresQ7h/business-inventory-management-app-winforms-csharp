﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Business_Inventory_Management_System
{
    public class OrderItem : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        public Product Product { get; set; }
        public string DisplayProuductText =>
            $"{Product.DisplayCode} | {Product.Name} | {Product.Category} | {Product.Price} $";

        private int _quantity;
        public int Quantity
        {
            get => _quantity;
            set
            {
                if (_quantity == value) return;
                _quantity = value;
                OnPropertyChanged(nameof(Quantity));
            }
        }

        public string? ProductID => this.Product?.DisplayCode; //Especially for the DGV to read it easily (cannot read somthing like Product.DisplayCode)
        public string? ProductName => this.Product?.Name; //Especially for the DGV to read it easily (cannot read somthing like Product.Name)


        public OrderItem() { }
        public OrderItem(Product product, int quantity)
        {
            this.Product = product;
            this.Quantity = quantity;
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class Order : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        public long ID { get; set; }
        public string DisplayCode => $"ORD-{ID}";

        private DateTime _createdDate = DateTime.Today;
        public DateTime CreatedDate
        {
            get => _createdDate;
            set
            {
                if (_createdDate == value) return;
                _createdDate = value;
                OnPropertyChanged(nameof(CreatedDate));
            }
        }
        public string DisplayCustomerText =>
            $"{Customer.DisplayCode} | {Customer.FirstName} | {Customer.LastName} | {Customer.Phone} | {Customer.Email}";

        private Customer _customer;
        public Customer Customer
        {
            get => _customer;
            set
            {
                if (_customer == value) return;
                _customer = value;
                OnPropertyChanged(nameof(Customer));
            }
        }


        private DateTime? _deliveredOnDate;

        public DateTime? DeliveredOnDate
        {
            get => _deliveredOnDate;
        }

        private string _status;
        public string Status
        {
            get => _status;
            set
            {
                if (_status == value) return;

                _status = value;

                if (_status == "Delivered")
                    _deliveredOnDate = DateTime.Today;
                else
                    _deliveredOnDate = null;

                OnPropertyChanged(nameof(Status));
                OnPropertyChanged(nameof(DeliveredOnDate));
            }
        }

        private DateTime _estimatedDeliveryDate;
        public DateTime EstimatedDeliveryDate
        {
            get => _estimatedDeliveryDate;
            set
            {
                if (_estimatedDeliveryDate == value) return;
                _estimatedDeliveryDate = value;
                OnPropertyChanged(nameof(EstimatedDeliveryDate));
            }
        }

        public decimal TotalPrice
        {
            get
            {
                decimal total = 0;
                foreach (OrderItem item in Items)
                {
                    total += item.Product.Price * item.Quantity;
                }
                return total;
            }
        }

        private BindingList<OrderItem> _items =
            new BindingList<OrderItem>();
        public BindingList<OrderItem> Items
        {
            get => _items;
            set
            {
                if (_items == value) return;

                if (_items != null)
                    _items.ListChanged -= Items_ListChanged; //resubsecribe to make sure

                _items = value;

                if (_items != null)
                    _items.ListChanged += Items_ListChanged;

                OnPropertyChanged(nameof(Items));
                OnPropertyChanged(nameof(TotalPrice)); //Because replacing the Items list does not fire ListChanged, we must notify TotalPrice manually in the setter.
            }
        }

        private string _description;
        public string Description
        {
            get => _description;
            set
            {
                if (_description == value) return;
                _description = value;
                OnPropertyChanged(nameof(Description));
            }
        }

        private static long IDSeed = 0;

        public Order() 
        {
            Items.ListChanged += Items_ListChanged; //Items.ListChanged: an event by the Binding list that fires when one of its items
        }

        public Order(Customer customer, string status, DateTime estimatedDelivery, BindingList<OrderItem> items, string descreption = "")
        {
            Items.ListChanged += Items_ListChanged; //Items.ListChanged: an event by the Binding list that fires when one of its items changes
            this.Customer = customer;
            this.Status = status;
            this.EstimatedDeliveryDate = estimatedDelivery;
            this.Items = items ?? new BindingList<OrderItem>();
            this.Description = descreption;
            this.ID = ++IDSeed;
        }

        public static void InitializeIDSeed(BindingList<Order> olist)
        {
            if (olist == null)
                return;
            IDSeed = 0;
            foreach (Order o in olist)
            {
                if (o.ID > IDSeed)
                    IDSeed = o.ID;
            }

        }

        public virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void Items_ListChanged(object sender, ListChangedEventArgs e)
        {
            OnPropertyChanged(nameof(TotalPrice));
        }
    }
}
