﻿namespace Business_Inventory_Management_System
{
    partial class FormLoginOrCreateNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLoginOrCreateNew));
            btnLogInOption = new Button();
            btnCreateNewOption = new Button();
            panelSelectOption = new Panel();
            panelShowOption = new Panel();
            panelSelectOption.SuspendLayout();
            SuspendLayout();
            // 
            // btnLogInOption
            // 
            btnLogInOption.BackColor = Color.Teal;
            btnLogInOption.BackgroundImageLayout = ImageLayout.None;
            btnLogInOption.Cursor = Cursors.Hand;
            btnLogInOption.Dock = DockStyle.Left;
            btnLogInOption.FlatAppearance.BorderColor = Color.Black;
            btnLogInOption.FlatStyle = FlatStyle.Flat;
            btnLogInOption.Font = new Font("Verdana", 12F);
            btnLogInOption.ForeColor = SystemColors.ControlLightLight;
            btnLogInOption.Image = (Image)resources.GetObject("btnLogInOption.Image");
            btnLogInOption.Location = new Point(0, 0);
            btnLogInOption.Name = "btnLogInOption";
            btnLogInOption.RightToLeft = RightToLeft.No;
            btnLogInOption.Size = new Size(219, 53);
            btnLogInOption.TabIndex = 0;
            btnLogInOption.Text = "Log In";
            btnLogInOption.TextAlign = ContentAlignment.MiddleRight;
            btnLogInOption.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnLogInOption.UseVisualStyleBackColor = false;
            btnLogInOption.Click += btnLogInOption_Click;
            // 
            // btnCreateNewOption
            // 
            btnCreateNewOption.BackColor = Color.Gray;
            btnCreateNewOption.Cursor = Cursors.Hand;
            btnCreateNewOption.Dock = DockStyle.Right;
            btnCreateNewOption.FlatAppearance.BorderColor = Color.Black;
            btnCreateNewOption.FlatStyle = FlatStyle.Flat;
            btnCreateNewOption.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCreateNewOption.ForeColor = SystemColors.ButtonHighlight;
            btnCreateNewOption.Image = (Image)resources.GetObject("btnCreateNewOption.Image");
            btnCreateNewOption.ImageAlign = ContentAlignment.MiddleRight;
            btnCreateNewOption.Location = new Point(217, 0);
            btnCreateNewOption.Name = "btnCreateNewOption";
            btnCreateNewOption.Size = new Size(219, 53);
            btnCreateNewOption.TabIndex = 1;
            btnCreateNewOption.Text = " Create New";
            btnCreateNewOption.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCreateNewOption.UseVisualStyleBackColor = false;
            btnCreateNewOption.Click += btnCreateNewOption_Click;
            // 
            // panelSelectOption
            // 
            panelSelectOption.BackColor = Color.Gray;
            panelSelectOption.BorderStyle = BorderStyle.FixedSingle;
            panelSelectOption.Controls.Add(btnLogInOption);
            panelSelectOption.Controls.Add(btnCreateNewOption);
            panelSelectOption.Dock = DockStyle.Top;
            panelSelectOption.ForeColor = SystemColors.ControlText;
            panelSelectOption.Location = new Point(0, 0);
            panelSelectOption.Name = "panelSelectOption";
            panelSelectOption.Size = new Size(438, 55);
            panelSelectOption.TabIndex = 7;
            // 
            // panelShowOption
            // 
            panelShowOption.BackColor = Color.Gray;
            panelShowOption.Dock = DockStyle.Fill;
            panelShowOption.Location = new Point(0, 55);
            panelShowOption.Name = "panelShowOption";
            panelShowOption.Size = new Size(438, 445);
            panelShowOption.TabIndex = 8;
            // 
            // FormLoginOrCreateNew
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkCyan;
            ClientSize = new Size(438, 500);
            Controls.Add(panelShowOption);
            Controls.Add(panelSelectOption);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FormLoginOrCreateNew";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "My Bussiness Inventory Manager";
            TopMost = true;
            Load += FormLoginOrCreateNew_Load;
            panelSelectOption.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button btnLogInOption;
        private Button btnCreateNewOption;
        private Panel panelSelectOption;
        private Panel panelShowOption;
    }
}