﻿namespace Business_Inventory_Management_System
{
    partial class FormMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            panelNavigation = new Panel();
            brnChangePassword = new Button();
            btnLogOut = new Button();
            btnReports = new Button();
            btnOrders = new Button();
            btnCustomers = new Button();
            btnProducts = new Button();
            btnHome = new Button();
            pbxSystemLogo = new PictureBox();
            panelHeaderBusinessName = new Panel();
            lblBusinessName = new Label();
            lblSectionTitle = new Label();
            panelHeaderTitel = new Panel();
            panelSectionContent = new Panel();
            panelNavigation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbxSystemLogo).BeginInit();
            panelHeaderBusinessName.SuspendLayout();
            panelHeaderTitel.SuspendLayout();
            SuspendLayout();
            // 
            // panelNavigation
            // 
            panelNavigation.BackColor = Color.CadetBlue;
            panelNavigation.Controls.Add(brnChangePassword);
            panelNavigation.Controls.Add(btnLogOut);
            panelNavigation.Controls.Add(btnReports);
            panelNavigation.Controls.Add(btnOrders);
            panelNavigation.Controls.Add(btnCustomers);
            panelNavigation.Controls.Add(btnProducts);
            panelNavigation.Controls.Add(btnHome);
            panelNavigation.Controls.Add(pbxSystemLogo);
            panelNavigation.Dock = DockStyle.Left;
            panelNavigation.Location = new Point(0, 0);
            panelNavigation.Name = "panelNavigation";
            panelNavigation.Size = new Size(157, 691);
            panelNavigation.TabIndex = 0;
            // 
            // brnChangePassword
            // 
            brnChangePassword.Dock = DockStyle.Bottom;
            brnChangePassword.FlatAppearance.BorderColor = Color.Black;
            brnChangePassword.FlatStyle = FlatStyle.Flat;
            brnChangePassword.Font = new Font("Verdana", 11F);
            brnChangePassword.ForeColor = SystemColors.ControlLightLight;
            brnChangePassword.Image = Properties.Resources.changePasswordIcon;
            brnChangePassword.Location = new Point(0, 575);
            brnChangePassword.Name = "brnChangePassword";
            brnChangePassword.Padding = new Padding(10, 0, 0, 0);
            brnChangePassword.RightToLeft = RightToLeft.No;
            brnChangePassword.Size = new Size(157, 58);
            brnChangePassword.TabIndex = 9;
            brnChangePassword.Text = "Change Password";
            brnChangePassword.TextImageRelation = TextImageRelation.ImageBeforeText;
            brnChangePassword.UseVisualStyleBackColor = true;
            brnChangePassword.Click += brnChangePassword_Click;
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.White;
            btnLogOut.Dock = DockStyle.Bottom;
            btnLogOut.Font = new Font("Segoe UI", 11F);
            btnLogOut.Image = Properties.Resources.logOutIcon;
            btnLogOut.Location = new Point(0, 633);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Padding = new Padding(5, 0, 0, 0);
            btnLogOut.Size = new Size(157, 58);
            btnLogOut.TabIndex = 8;
            btnLogOut.Text = " Log out";
            btnLogOut.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // btnReports
            // 
            btnReports.Dock = DockStyle.Top;
            btnReports.FlatAppearance.BorderColor = Color.Black;
            btnReports.FlatStyle = FlatStyle.Flat;
            btnReports.Font = new Font("Verdana", 11F);
            btnReports.ForeColor = SystemColors.ControlLightLight;
            btnReports.Image = Properties.Resources.reportsIcon;
            btnReports.ImageAlign = ContentAlignment.MiddleLeft;
            btnReports.Location = new Point(0, 315);
            btnReports.Name = "btnReports";
            btnReports.Padding = new Padding(6, 0, 0, 0);
            btnReports.RightToLeft = RightToLeft.No;
            btnReports.Size = new Size(157, 58);
            btnReports.TabIndex = 5;
            btnReports.Text = " Reports";
            btnReports.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnReports.UseVisualStyleBackColor = true;
            btnReports.Click += btnReports_Click;
            // 
            // btnOrders
            // 
            btnOrders.Dock = DockStyle.Top;
            btnOrders.FlatAppearance.BorderColor = Color.Black;
            btnOrders.FlatStyle = FlatStyle.Flat;
            btnOrders.Font = new Font("Verdana", 11F);
            btnOrders.ForeColor = SystemColors.ControlLightLight;
            btnOrders.Image = Properties.Resources.ordersIcon;
            btnOrders.ImageAlign = ContentAlignment.MiddleLeft;
            btnOrders.Location = new Point(0, 257);
            btnOrders.Name = "btnOrders";
            btnOrders.Size = new Size(157, 58);
            btnOrders.TabIndex = 6;
            btnOrders.Text = "Orders";
            btnOrders.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnOrders.UseVisualStyleBackColor = true;
            btnOrders.Click += btnOrders_Click;
            // 
            // btnCustomers
            // 
            btnCustomers.Dock = DockStyle.Top;
            btnCustomers.FlatAppearance.BorderColor = Color.Black;
            btnCustomers.FlatStyle = FlatStyle.Flat;
            btnCustomers.Font = new Font("Verdana", 11F);
            btnCustomers.ForeColor = SystemColors.ControlLightLight;
            btnCustomers.Image = Properties.Resources.customersIcon;
            btnCustomers.Location = new Point(0, 199);
            btnCustomers.Name = "btnCustomers";
            btnCustomers.Size = new Size(157, 58);
            btnCustomers.TabIndex = 4;
            btnCustomers.Text = "Customers";
            btnCustomers.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCustomers.UseVisualStyleBackColor = true;
            btnCustomers.Click += btnCustomers_Click;
            // 
            // btnProducts
            // 
            btnProducts.Dock = DockStyle.Top;
            btnProducts.FlatAppearance.BorderColor = Color.Black;
            btnProducts.FlatStyle = FlatStyle.Flat;
            btnProducts.Font = new Font("Verdana", 11F);
            btnProducts.ForeColor = SystemColors.ControlLightLight;
            btnProducts.Image = Properties.Resources.productsIcon;
            btnProducts.Location = new Point(0, 141);
            btnProducts.Name = "btnProducts";
            btnProducts.Size = new Size(157, 58);
            btnProducts.TabIndex = 7;
            btnProducts.Text = " Products";
            btnProducts.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnProducts.UseVisualStyleBackColor = true;
            btnProducts.Click += btnProducts_Click;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.Teal;
            btnHome.Dock = DockStyle.Top;
            btnHome.FlatAppearance.BorderColor = Color.Black;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.Font = new Font("Verdana", 11F);
            btnHome.ForeColor = SystemColors.ControlLightLight;
            btnHome.Image = Properties.Resources.homeIcon;
            btnHome.ImageAlign = ContentAlignment.MiddleLeft;
            btnHome.Location = new Point(0, 83);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(157, 58);
            btnHome.TabIndex = 3;
            btnHome.Text = "Home";
            btnHome.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // pbxSystemLogo
            // 
            pbxSystemLogo.Dock = DockStyle.Top;
            pbxSystemLogo.Image = (Image)resources.GetObject("pbxSystemLogo.Image");
            pbxSystemLogo.ImageLocation = "";
            pbxSystemLogo.Location = new Point(0, 0);
            pbxSystemLogo.Name = "pbxSystemLogo";
            pbxSystemLogo.Size = new Size(157, 83);
            pbxSystemLogo.SizeMode = PictureBoxSizeMode.CenterImage;
            pbxSystemLogo.TabIndex = 0;
            pbxSystemLogo.TabStop = false;
            // 
            // panelHeaderBusinessName
            // 
            panelHeaderBusinessName.Controls.Add(lblBusinessName);
            panelHeaderBusinessName.Dock = DockStyle.Top;
            panelHeaderBusinessName.Location = new Point(157, 0);
            panelHeaderBusinessName.Name = "panelHeaderBusinessName";
            panelHeaderBusinessName.Size = new Size(772, 36);
            panelHeaderBusinessName.TabIndex = 1;
            // 
            // lblBusinessName
            // 
            lblBusinessName.BackColor = Color.CadetBlue;
            lblBusinessName.Dock = DockStyle.Fill;
            lblBusinessName.Font = new Font("Microsoft YaHei UI", 13F);
            lblBusinessName.ForeColor = SystemColors.ControlLightLight;
            lblBusinessName.Location = new Point(0, 0);
            lblBusinessName.Name = "lblBusinessName";
            lblBusinessName.Size = new Size(772, 36);
            lblBusinessName.TabIndex = 3;
            lblBusinessName.Text = "BusinessName";
            lblBusinessName.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblSectionTitle
            // 
            lblSectionTitle.BackColor = Color.CadetBlue;
            lblSectionTitle.Dock = DockStyle.Fill;
            lblSectionTitle.Font = new Font("Verdana", 15F);
            lblSectionTitle.Location = new Point(0, 0);
            lblSectionTitle.Name = "lblSectionTitle";
            lblSectionTitle.Padding = new Padding(0, 0, 3, 0);
            lblSectionTitle.Size = new Size(770, 45);
            lblSectionTitle.TabIndex = 1;
            lblSectionTitle.Text = "Home";
            lblSectionTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelHeaderTitel
            // 
            panelHeaderTitel.BackColor = Color.Black;
            panelHeaderTitel.BorderStyle = BorderStyle.FixedSingle;
            panelHeaderTitel.Controls.Add(lblSectionTitle);
            panelHeaderTitel.Dock = DockStyle.Top;
            panelHeaderTitel.Location = new Point(157, 36);
            panelHeaderTitel.Name = "panelHeaderTitel";
            panelHeaderTitel.Size = new Size(772, 47);
            panelHeaderTitel.TabIndex = 2;
            // 
            // panelSectionContent
            // 
            panelSectionContent.BorderStyle = BorderStyle.FixedSingle;
            panelSectionContent.Dock = DockStyle.Fill;
            panelSectionContent.Location = new Point(157, 83);
            panelSectionContent.Name = "panelSectionContent";
            panelSectionContent.Size = new Size(772, 608);
            panelSectionContent.TabIndex = 3;
            // 
            // FormMain
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(929, 691);
            Controls.Add(panelSectionContent);
            Controls.Add(panelHeaderTitel);
            Controls.Add(panelHeaderBusinessName);
            Controls.Add(panelNavigation);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FormMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "My Bussiness Inventory Manager";
            FormClosed += FormMain_FormClosed;
            Load += FormMain_Load;
            panelNavigation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pbxSystemLogo).EndInit();
            panelHeaderBusinessName.ResumeLayout(false);
            panelHeaderTitel.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panelNavigation;
        private Panel panelHeaderBusinessName;
        private Label lblSectionTitle;
        private Label lblBusinessName;
        private Panel panelHeaderTitel;
        private PictureBox pbxSystemLogo;
        private Button btnHome;
        private Button btnReports;
        private Button btnOrders;
        private Button btnCustomers;
        private Button btnProducts;
        private Button btnLogOut;
        private Panel panelSectionContent;
        private Button brnChangePassword;
    }
}
