﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Text.Json;

namespace Business_Inventory_Management_System
{
    public partial class FormCreate : Form
    {
        public FormCreate()
        {
            InitializeComponent();
        }

        private void tbxNewBusinessName_TextChanged(object sender, EventArgs e)
        {
            UpdateCreateButtonState();
        }

        private void tbxNewPassword_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tbxNewPassword.Text))
            {
                Helpers.AvtivateTextBox(tbxConfirmPassword, SystemColors.Window);
                Helpers.AvtivateButton(btnShowOrHideConfirmPass, btnShowOrHideConfirmPass.BackColor);
            }
            else
            {
                Helpers.DeavtivateTextBox(tbxConfirmPassword, Color.DarkGray);
                Helpers.DeavtivateButton(btnShowOrHideConfirmPass, btnShowOrHideConfirmPass.BackColor);
            }
            UpdateCreateButtonState();
            UpdatePasswordNotMatchLabel();
        }

        private void tbxConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            UpdateCreateButtonState();
            UpdatePasswordNotMatchLabel();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (Helpers.systemBusinessesList.Contains(tbxNewBusinessName.Text))
            {
                MessageBox.Show($"A business with the name ({tbxNewBusinessName.Text}) already exists.\nPlease choose a new name.",
                    "Duplicate Business",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            string businessPath = Path.Combine(
                Helpers.systemDataFolderPath,
                tbxNewBusinessName.Text.Trim() //removes Leading spaces and Trailing spaces
            );

            //save business
            Directory.CreateDirectory(businessPath);



            //save the password
            string passwordPath = Path.Combine(businessPath, "Password.txt");
            File.WriteAllText(
                passwordPath,
                Helpers.HashPassword(tbxNewPassword.Text)
            );


            lblSuccessfulCreate.Visible = true;

            tbxNewBusinessName.Clear();
            tbxNewPassword.Clear();
            tbxConfirmPassword.Clear();


            Helpers.RefreshBusinessesList();

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void UpdateCreateButtonState()
        {
            bool canCreate =
                !string.IsNullOrEmpty(tbxNewBusinessName.Text) &&
                !string.IsNullOrEmpty(tbxNewPassword.Text) &&
                !string.IsNullOrEmpty(tbxConfirmPassword.Text) &&
                Helpers.PasswordsAreSame(tbxNewPassword.Text, tbxConfirmPassword.Text);

            if (canCreate)
                Helpers.AvtivateButton(btnCreate, Color.LightSeaGreen);
            else
                Helpers.DeavtivateButton(btnCreate, Color.DarkSlateGray);
        }

        private void UpdatePasswordNotMatchLabel()
        {
            if (!Helpers.PasswordsAreSame(tbxNewPassword.Text, tbxConfirmPassword.Text))
                lblPasswordNotMatch.Visible = true;
            else
                lblPasswordNotMatch.Visible = false;
        }

        private void btnShowOrHideConfirmPass_Click(object sender, EventArgs e)
        {
            Helpers.ChangeHideOrShowPassword(tbxConfirmPassword);
        }

        private void btnShowOrHideNewPass_Click(object sender, EventArgs e)
        {
            Helpers.ChangeHideOrShowPassword(tbxNewPassword);
        }
    }
}
