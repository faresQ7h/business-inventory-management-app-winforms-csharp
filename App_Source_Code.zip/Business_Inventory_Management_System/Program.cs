using System.Security.Permissions;

namespace Business_Inventory_Management_System
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetHighDpiMode(HighDpiMode.SystemAware);

            // switch between login and logout
            while (true)
            {
                //first call the login form and wait for the result, when finish clear resources
                using (var login = new FormLoginOrCreateNew())
                {
                    if (login.ShowDialog() != DialogResult.OK)
                        break;
                }

                //second call main form with seamilar logic
                using (var main = new FormMain())
                {
                    Application.Run(main);

                    // If user closed Main WITHOUT logging out then exit app
                    if (!main.IsLogout)
                        break;
                }

                //Repeat loop over again untill one of the event break it

            }
        }

    }
}