﻿namespace Business_Inventory_Management_System
{
    partial class FormReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            tlpReports = new TableLayoutPanel();
            panelLowStockProducts = new Panel();
            lblNoLowStockProducts = new Label();
            dgvLowStockProducts = new DataGridView();
            lblLowStockProductsTitle = new Label();
            panelMostActiveCustomers = new Panel();
            lblNoActiveCustomers = new Label();
            dgvMostActiveCustomers = new DataGridView();
            lblMostActiveCustomersTitle = new Label();
            panelMonthlySummary = new Panel();
            lblNoMonthlySummary = new Label();
            dgvMonthlySummary = new DataGridView();
            lblMonthlySummaryTitle = new Label();
            panelBestSellingProducts = new Panel();
            lblNoBestSellingProducts = new Label();
            dgvBestSellingProducts = new DataGridView();
            lblBestSellingProductsTitle = new Label();
            tlpReports.SuspendLayout();
            panelLowStockProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLowStockProducts).BeginInit();
            panelMostActiveCustomers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvMostActiveCustomers).BeginInit();
            panelMonthlySummary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvMonthlySummary).BeginInit();
            panelBestSellingProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBestSellingProducts).BeginInit();
            SuspendLayout();
            // 
            // tlpReports
            // 
            tlpReports.ColumnCount = 2;
            tlpReports.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57.8249321F));
            tlpReports.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42.1750679F));
            tlpReports.Controls.Add(panelLowStockProducts, 1, 1);
            tlpReports.Controls.Add(panelMostActiveCustomers, 0, 1);
            tlpReports.Controls.Add(panelMonthlySummary, 0, 0);
            tlpReports.Controls.Add(panelBestSellingProducts, 1, 0);
            tlpReports.Dock = DockStyle.Fill;
            tlpReports.Location = new Point(0, 0);
            tlpReports.Name = "tlpReports";
            tlpReports.RowCount = 2;
            tlpReports.RowStyles.Add(new RowStyle(SizeType.Percent, 56.506237F));
            tlpReports.RowStyles.Add(new RowStyle(SizeType.Percent, 43.493763F));
            tlpReports.Size = new Size(754, 561);
            tlpReports.TabIndex = 0;
            // 
            // panelLowStockProducts
            // 
            panelLowStockProducts.BorderStyle = BorderStyle.FixedSingle;
            panelLowStockProducts.Controls.Add(lblNoLowStockProducts);
            panelLowStockProducts.Controls.Add(dgvLowStockProducts);
            panelLowStockProducts.Controls.Add(lblLowStockProductsTitle);
            panelLowStockProducts.Dock = DockStyle.Fill;
            panelLowStockProducts.Location = new Point(439, 319);
            panelLowStockProducts.Name = "panelLowStockProducts";
            panelLowStockProducts.Size = new Size(312, 239);
            panelLowStockProducts.TabIndex = 3;
            // 
            // lblNoLowStockProducts
            // 
            lblNoLowStockProducts.Anchor = AnchorStyles.None;
            lblNoLowStockProducts.AutoSize = true;
            lblNoLowStockProducts.BackColor = Color.Gainsboro;
            lblNoLowStockProducts.Font = new Font("Segoe UI", 11F);
            lblNoLowStockProducts.ForeColor = Color.Teal;
            lblNoLowStockProducts.Location = new Point(58, 124);
            lblNoLowStockProducts.Name = "lblNoLowStockProducts";
            lblNoLowStockProducts.Size = new Size(206, 25);
            lblNoLowStockProducts.TabIndex = 4;
            lblNoLowStockProducts.Text = "No low-stock products.";
            lblNoLowStockProducts.Visible = false;
            // 
            // dgvLowStockProducts
            // 
            dgvLowStockProducts.AllowUserToAddRows = false;
            dgvLowStockProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLowStockProducts.BackgroundColor = Color.Gainsboro;
            dgvLowStockProducts.BorderStyle = BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvLowStockProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvLowStockProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvLowStockProducts.DefaultCellStyle = dataGridViewCellStyle2;
            dgvLowStockProducts.Dock = DockStyle.Fill;
            dgvLowStockProducts.Location = new Point(0, 35);
            dgvLowStockProducts.Name = "dgvLowStockProducts";
            dgvLowStockProducts.ReadOnly = true;
            dgvLowStockProducts.RowHeadersVisible = false;
            dgvLowStockProducts.RowHeadersWidth = 51;
            dgvLowStockProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvLowStockProducts.Size = new Size(310, 202);
            dgvLowStockProducts.TabIndex = 3;
            // 
            // lblLowStockProductsTitle
            // 
            lblLowStockProductsTitle.AutoSize = true;
            lblLowStockProductsTitle.Dock = DockStyle.Top;
            lblLowStockProductsTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblLowStockProductsTitle.ForeColor = SystemColors.ButtonHighlight;
            lblLowStockProductsTitle.Location = new Point(0, 0);
            lblLowStockProductsTitle.Name = "lblLowStockProductsTitle";
            lblLowStockProductsTitle.Size = new Size(244, 35);
            lblLowStockProductsTitle.TabIndex = 2;
            lblLowStockProductsTitle.Text = "Low Stock Products";
            // 
            // panelMostActiveCustomers
            // 
            panelMostActiveCustomers.BorderStyle = BorderStyle.FixedSingle;
            panelMostActiveCustomers.Controls.Add(lblNoActiveCustomers);
            panelMostActiveCustomers.Controls.Add(dgvMostActiveCustomers);
            panelMostActiveCustomers.Controls.Add(lblMostActiveCustomersTitle);
            panelMostActiveCustomers.Dock = DockStyle.Fill;
            panelMostActiveCustomers.Location = new Point(3, 319);
            panelMostActiveCustomers.Name = "panelMostActiveCustomers";
            panelMostActiveCustomers.Size = new Size(430, 239);
            panelMostActiveCustomers.TabIndex = 2;
            // 
            // lblNoActiveCustomers
            // 
            lblNoActiveCustomers.Anchor = AnchorStyles.None;
            lblNoActiveCustomers.AutoSize = true;
            lblNoActiveCustomers.BackColor = Color.Gainsboro;
            lblNoActiveCustomers.Font = new Font("Segoe UI", 11F);
            lblNoActiveCustomers.ForeColor = Color.Teal;
            lblNoActiveCustomers.Location = new Point(88, 124);
            lblNoActiveCustomers.Name = "lblNoActiveCustomers";
            lblNoActiveCustomers.Size = new Size(257, 25);
            lblNoActiveCustomers.TabIndex = 4;
            lblNoActiveCustomers.Text = "No active customers to show.";
            lblNoActiveCustomers.Visible = false;
            // 
            // dgvMostActiveCustomers
            // 
            dgvMostActiveCustomers.AllowUserToAddRows = false;
            dgvMostActiveCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvMostActiveCustomers.BackgroundColor = Color.Gainsboro;
            dgvMostActiveCustomers.BorderStyle = BorderStyle.Fixed3D;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgvMostActiveCustomers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgvMostActiveCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Window;
            dataGridViewCellStyle4.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle4.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            dgvMostActiveCustomers.DefaultCellStyle = dataGridViewCellStyle4;
            dgvMostActiveCustomers.Dock = DockStyle.Fill;
            dgvMostActiveCustomers.Location = new Point(0, 35);
            dgvMostActiveCustomers.Name = "dgvMostActiveCustomers";
            dgvMostActiveCustomers.ReadOnly = true;
            dgvMostActiveCustomers.RowHeadersVisible = false;
            dgvMostActiveCustomers.RowHeadersWidth = 51;
            dgvMostActiveCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvMostActiveCustomers.Size = new Size(428, 202);
            dgvMostActiveCustomers.TabIndex = 3;
            // 
            // lblMostActiveCustomersTitle
            // 
            lblMostActiveCustomersTitle.AutoSize = true;
            lblMostActiveCustomersTitle.Dock = DockStyle.Top;
            lblMostActiveCustomersTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblMostActiveCustomersTitle.ForeColor = SystemColors.ButtonHighlight;
            lblMostActiveCustomersTitle.Location = new Point(0, 0);
            lblMostActiveCustomersTitle.Name = "lblMostActiveCustomersTitle";
            lblMostActiveCustomersTitle.Size = new Size(289, 35);
            lblMostActiveCustomersTitle.TabIndex = 2;
            lblMostActiveCustomersTitle.Text = "Most Active Customers";
            // 
            // panelMonthlySummary
            // 
            panelMonthlySummary.BorderStyle = BorderStyle.FixedSingle;
            panelMonthlySummary.Controls.Add(lblNoMonthlySummary);
            panelMonthlySummary.Controls.Add(dgvMonthlySummary);
            panelMonthlySummary.Controls.Add(lblMonthlySummaryTitle);
            panelMonthlySummary.Dock = DockStyle.Fill;
            panelMonthlySummary.Location = new Point(3, 3);
            panelMonthlySummary.Name = "panelMonthlySummary";
            panelMonthlySummary.Size = new Size(430, 310);
            panelMonthlySummary.TabIndex = 0;
            // 
            // lblNoMonthlySummary
            // 
            lblNoMonthlySummary.Anchor = AnchorStyles.None;
            lblNoMonthlySummary.AutoSize = true;
            lblNoMonthlySummary.BackColor = Color.Gainsboro;
            lblNoMonthlySummary.Font = new Font("Segoe UI", 11F);
            lblNoMonthlySummary.ForeColor = Color.Teal;
            lblNoMonthlySummary.Location = new Point(78, 149);
            lblNoMonthlySummary.Name = "lblNoMonthlySummary";
            lblNoMonthlySummary.Size = new Size(283, 25);
            lblNoMonthlySummary.TabIndex = 4;
            lblNoMonthlySummary.Text = "No monthly sales data available.";
            lblNoMonthlySummary.Visible = false;
            // 
            // dgvMonthlySummary
            // 
            dgvMonthlySummary.AllowUserToAddRows = false;
            dgvMonthlySummary.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvMonthlySummary.BackgroundColor = Color.Gainsboro;
            dgvMonthlySummary.BorderStyle = BorderStyle.Fixed3D;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Control;
            dataGridViewCellStyle5.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            dgvMonthlySummary.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            dgvMonthlySummary.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = SystemColors.Window;
            dataGridViewCellStyle6.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle6.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            dgvMonthlySummary.DefaultCellStyle = dataGridViewCellStyle6;
            dgvMonthlySummary.Dock = DockStyle.Fill;
            dgvMonthlySummary.Location = new Point(0, 35);
            dgvMonthlySummary.Name = "dgvMonthlySummary";
            dgvMonthlySummary.ReadOnly = true;
            dgvMonthlySummary.RowHeadersVisible = false;
            dgvMonthlySummary.RowHeadersWidth = 51;
            dgvMonthlySummary.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvMonthlySummary.Size = new Size(428, 273);
            dgvMonthlySummary.TabIndex = 3;
            // 
            // lblMonthlySummaryTitle
            // 
            lblMonthlySummaryTitle.AutoSize = true;
            lblMonthlySummaryTitle.Dock = DockStyle.Top;
            lblMonthlySummaryTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblMonthlySummaryTitle.ForeColor = SystemColors.ButtonHighlight;
            lblMonthlySummaryTitle.Location = new Point(0, 0);
            lblMonthlySummaryTitle.Name = "lblMonthlySummaryTitle";
            lblMonthlySummaryTitle.Size = new Size(299, 35);
            lblMonthlySummaryTitle.TabIndex = 2;
            lblMonthlySummaryTitle.Text = "Monthly Sales Summary";
            // 
            // panelBestSellingProducts
            // 
            panelBestSellingProducts.BorderStyle = BorderStyle.FixedSingle;
            panelBestSellingProducts.Controls.Add(lblNoBestSellingProducts);
            panelBestSellingProducts.Controls.Add(dgvBestSellingProducts);
            panelBestSellingProducts.Controls.Add(lblBestSellingProductsTitle);
            panelBestSellingProducts.Dock = DockStyle.Fill;
            panelBestSellingProducts.Location = new Point(439, 3);
            panelBestSellingProducts.Name = "panelBestSellingProducts";
            panelBestSellingProducts.Size = new Size(312, 310);
            panelBestSellingProducts.TabIndex = 1;
            // 
            // lblNoBestSellingProducts
            // 
            lblNoBestSellingProducts.Anchor = AnchorStyles.None;
            lblNoBestSellingProducts.AutoSize = true;
            lblNoBestSellingProducts.BackColor = Color.Gainsboro;
            lblNoBestSellingProducts.Font = new Font("Segoe UI", 11F);
            lblNoBestSellingProducts.ForeColor = Color.Teal;
            lblNoBestSellingProducts.Location = new Point(8, 149);
            lblNoBestSellingProducts.Name = "lblNoBestSellingProducts";
            lblNoBestSellingProducts.Size = new Size(294, 25);
            lblNoBestSellingProducts.TabIndex = 4;
            lblNoBestSellingProducts.Text = "No best-selling products to show.";
            lblNoBestSellingProducts.Visible = false;
            // 
            // dgvBestSellingProducts
            // 
            dgvBestSellingProducts.AllowUserToAddRows = false;
            dgvBestSellingProducts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvBestSellingProducts.BackgroundColor = Color.Gainsboro;
            dgvBestSellingProducts.BorderStyle = BorderStyle.Fixed3D;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = SystemColors.Control;
            dataGridViewCellStyle7.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.True;
            dgvBestSellingProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            dgvBestSellingProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = SystemColors.Window;
            dataGridViewCellStyle8.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle8.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            dgvBestSellingProducts.DefaultCellStyle = dataGridViewCellStyle8;
            dgvBestSellingProducts.Dock = DockStyle.Fill;
            dgvBestSellingProducts.Location = new Point(0, 35);
            dgvBestSellingProducts.Name = "dgvBestSellingProducts";
            dgvBestSellingProducts.ReadOnly = true;
            dgvBestSellingProducts.RowHeadersVisible = false;
            dgvBestSellingProducts.RowHeadersWidth = 51;
            dgvBestSellingProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvBestSellingProducts.Size = new Size(310, 273);
            dgvBestSellingProducts.TabIndex = 3;
            // 
            // lblBestSellingProductsTitle
            // 
            lblBestSellingProductsTitle.AutoSize = true;
            lblBestSellingProductsTitle.Dock = DockStyle.Top;
            lblBestSellingProductsTitle.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblBestSellingProductsTitle.ForeColor = SystemColors.ButtonHighlight;
            lblBestSellingProductsTitle.Location = new Point(0, 0);
            lblBestSellingProductsTitle.Name = "lblBestSellingProductsTitle";
            lblBestSellingProductsTitle.Size = new Size(264, 35);
            lblBestSellingProductsTitle.TabIndex = 2;
            lblBestSellingProductsTitle.Text = "Best-Selling Products";
            // 
            // FormReports
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(754, 561);
            Controls.Add(tlpReports);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormReports";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormReports";
            Load += FormReports_Load;
            tlpReports.ResumeLayout(false);
            panelLowStockProducts.ResumeLayout(false);
            panelLowStockProducts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLowStockProducts).EndInit();
            panelMostActiveCustomers.ResumeLayout(false);
            panelMostActiveCustomers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvMostActiveCustomers).EndInit();
            panelMonthlySummary.ResumeLayout(false);
            panelMonthlySummary.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvMonthlySummary).EndInit();
            panelBestSellingProducts.ResumeLayout(false);
            panelBestSellingProducts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBestSellingProducts).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tlpReports;
        private Panel panelLowStockProducts;
        private Panel panelMostActiveCustomers;
        private Panel panelMonthlySummary;
        private Panel panelBestSellingProducts;
        private Label lblLowStockProductsTitle;
        private Label lblMostActiveCustomersTitle;
        private Label lblMonthlySummaryTitle;
        private Label lblBestSellingProductsTitle;
        private DataGridView dgvLowStockProducts;
        private DataGridView dgvMostActiveCustomers;
        private DataGridView dgvMonthlySummary;
        private DataGridView dgvBestSellingProducts;
        private Label lblNoLowStockProducts;
        private Label lblNoActiveCustomers;
        private Label lblNoMonthlySummary;
        private Label lblNoBestSellingProducts;
    }
}