﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormLogin : Form
    {

        public event EventHandler LoginSucceeded;

        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            if (Helpers.systemBusinessesList.Length == 0)
            {
                lblEmptyBussinssList.Visible = true;
            }
            else
            {
                lblEmptyBussinssList.Visible = false;
                lbxBusinessesList.DataSource = Helpers.systemBusinessesList;
            }
        }

        private void lbxBusinessesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxBusinessesList.SelectedIndex != -1)
            {
                Helpers.AvtivateButton(btnShowOrHidePass, btnShowOrHidePass.BackColor);
                Helpers.AvtivateTextBox(tbxPassword, SystemColors.Window);
            }
            else
            {
                Helpers.DeavtivateButton(btnShowOrHidePass, btnShowOrHidePass.BackColor);
                Helpers.DeavtivateTextBox(tbxPassword, Color.DarkGray);
            }
        }

        private void btnShowOrHidePass_Click(object sender, EventArgs e)
        {
            Helpers.ChangeHideOrShowPassword(tbxPassword);
        }

        private void tbxPassword_TextChanged(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(tbxPassword.Text))
            {
                Helpers.AvtivateButton(btnLogIn, Color.LightSeaGreen);
                Helpers.AvtivateButton(btnDelete, SystemColors.Window);
                btnDelete.ForeColor = Color.Black;
            }
            else
            {
                Helpers.DeavtivateButton(btnLogIn, Color.DarkSlateGray);
                Helpers.DeavtivateButton(btnDelete, Color.LightGray);
                btnDelete.ForeColor = SystemColors.ControlDark;
            }
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            if (!IsCorrectPassword())
            {
                lblPasswordWrong.Visible = true;
                tbxPassword.Clear();
                return;
            }
            Helpers.SetSelectedBusiness(lbxBusinessesList.SelectedItem.ToString());

            LoginSucceeded?.Invoke(this, EventArgs.Empty);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!IsCorrectPassword())
            {
                lblPasswordWrong.Visible = true;
                tbxPassword.Clear();
                return;
            }

            DialogResult result = MessageBox.Show(
            $"Are you sure you want to delete the business \"{lbxBusinessesList.SelectedItem.ToString()}\"?\n\n" +
            "This action is permanent and data cannot be retrived.",
            "Confirm Deletion",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    string path = Path.Combine(
                        Helpers.systemDataFolderPath,
                        lbxBusinessesList.SelectedItem.ToString()
                    );
                    //delete actual data folder
                    Directory.Delete(path, true);

                    //refresh the list and show again
                    Helpers.RefreshBusinessesList();

                    lbxBusinessesList.DataSource = null;
                    lbxBusinessesList.DataSource = Helpers.systemBusinessesList;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Failed to delete the business.\n" + ex.Message,
                        "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }

            tbxPassword.Clear();
            lblPasswordWrong.Visible = false;

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private bool IsCorrectPassword()
        {
            string businessPath = Path.Combine(
                Helpers.systemDataFolderPath,
                lbxBusinessesList.SelectedItem.ToString()
            );

            string passwordFile = Path.Combine(businessPath, "Password.txt");

            //check file exists
            if (!File.Exists(passwordFile))
                return false;

            string savedHash = File.ReadAllText(passwordFile);
            string enteredHash = Helpers.HashPassword(tbxPassword.Text);

            // 3️⃣ Compare hashes
            return string.Equals(savedHash, enteredHash, StringComparison.Ordinal);
        }

    }
}
