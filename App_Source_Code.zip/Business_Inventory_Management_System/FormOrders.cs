﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormOrders : Form
    {
        //
        //
        //used ONLY for FormOrderInfo sending data
        public static long ID { get; set; }

        public static Customer Customer { get; set; }

        public static string Status { get; set; }

        public static DateTime? EstimatedDelivary { get; set; }

        public static string Description { get; set; }

        public static BindingList<OrderItem> Items { get; set; } =
            new BindingList<OrderItem>();
        //used ONLY for FormOrderInfo sending data
        //
        //

        public static BindingList<Order> Orders =
                 Helpers.LoadJsonToBindingList<Order>("Orders.Json");

        public FormOrders()
        {
            InitializeComponent();
            Order.InitializeIDSeed(Orders);
        }

        private void FormOrders_Load(object sender, EventArgs e)
        {
            // dgv Orders
            FormatOrdersGrid();
            dgvOrders.DataSource = Orders;


            // dgv OrderItems
            FormatOrdersItemsGrid();
            UpdateOrderItemsGrid();

            UpdateEditDeleteButtonsAndNoSelectedOrderLabel();
            UpdateEmptyOrdersLabel();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using FormOrderInfo frm = new FormOrderInfo('A');
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;

            Orders.Add(
                new Order(Customer, Status, (DateTime)EstimatedDelivary, Items, Description)
                );
            UpdateEmptyOrdersLabel();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Order o = dgvOrders.CurrentRow.DataBoundItem as Order;
            using FormOrderInfo frm = new FormOrderInfo('E', o);
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;

            o.Customer = Customer;
            o.Status = Status;
            o.EstimatedDeliveryDate = (DateTime)EstimatedDelivary;
            o.Items = Items;
            o.Description = Description;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
            $"Are you sure you want to delete product with ID({(dgvOrders.CurrentRow.DataBoundItem as Order).DisplayCode})?\n\nThis action cannot be undone.",
            "Confirm Delete",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            Order p = dgvOrders.CurrentRow.DataBoundItem as Order;
            Orders.Remove(p);

            if (dgvOrders.DataSource is BindingList<Order> currentList &&
            currentList != Orders) //delete from dgv if the list is a temp searching 
            {
                currentList.Remove(p);
            }
            UpdateEmptyOrdersLabel();
            UpdateOrderItemsGrid();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using FormOrderInfo frm = new FormOrderInfo('S');
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;

            BindingList<Order> temp = new BindingList<Order>();
            foreach (Order o in Orders)
            {
                bool match = true;

                if (!string.IsNullOrWhiteSpace(Status) &&
                    !o.Status.Contains(Status, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (!string.IsNullOrWhiteSpace(Description) &&
                    !o.Description.Contains(Description, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (Customer != null && o.Customer != Customer)
                    match = false;

                if (Items.Count > 0)
                {
                    foreach (OrderItem item in Items)
                    {
                        bool found = o.Items.Any(orderItem =>     //search for orrder that has the selected Items
                            orderItem.Product == item.Product &&
                            orderItem.Quantity == item.Quantity);

                        if (!found)
                        {
                            match = false;
                            break;
                        }
                    }
                }

                if (ID > 0 && o.ID != ID)
                    match = false;

                if (EstimatedDelivary.HasValue &&
                    o.EstimatedDeliveryDate.Date != EstimatedDelivary.Value.Date)
                    match = false;

                if (match)
                    temp.Add(o);
            }

            dgvOrders.DataSource = temp;

            if (temp.Count == 0)
                lblNoResults.Visible = true;
            else lblNoResults.Visible = false;

            UpdateEmptyOrdersLabel();
            UpdateEditDeleteButtonsAndNoSelectedOrderLabel();
            UpdateOrderItemsGrid();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lblNoResults.Visible = false;
            dgvOrders.DataSource = Orders;
        }

        private void dgvOrders_SelectionChanged(object sender, EventArgs e)
        {
            UpdateOrderItemsGrid();
            UpdateEditDeleteButtonsAndNoSelectedOrderLabel();
        }

        private void FormOrders_FormClosing(object sender, FormClosingEventArgs e)
        {
            Helpers.SaveBindingListToJson<Order>(Orders, "Orders.json");
        }


        //
        //
        //Used functions
        void UpdateEditDeleteButtonsAndNoSelectedOrderLabel()
        {
            if (dgvOrders.SelectedRows.Count > 0)
            {
                Helpers.AvtivateButton(btnEdit, Color.LightSeaGreen);
                Helpers.AvtivateButton(btnDelete, Color.LightSeaGreen);
                lblNoSelectedOrder.Visible = false;
            }
            else
            {
                Helpers.DeavtivateButton(btnEdit, Color.DarkSlateGray);
                Helpers.DeavtivateButton(btnDelete, Color.DarkSlateGray);
                lblNoSelectedOrder.Visible = true;
            }

        }

        void UpdateEmptyOrdersLabel()
        {
            if (Orders.Count == 0)
            {
                lblEmptyOrdersList.Visible = true;
                UpdateOrderItemsGrid();
            }
            else
                lblEmptyOrdersList.Visible = false;
        }

        private void UpdateOrderItemsGrid()
        {
            if (Orders.Count == 0 || dgvOrders.CurrentRow == null)
            {
                dgvOrderItems.DataSource = new BindingList<OrderItem>();
                return;
            }

            dgvOrderItems.DataSource =
                (dgvOrders.CurrentRow.DataBoundItem as Order).Items; ;
        }

        private void FormatOrdersGrid()
        {
            dgvOrders.AutoGenerateColumns = false;
            dgvOrders.Columns.Clear();

            dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "ID",
                DataPropertyName = "DisplayCode",
                Name = "ID",
                ReadOnly = true,
                Width = 80
            });

            dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Created On",
                DataPropertyName = "CreatedDate",
                DefaultCellStyle = new DataGridViewCellStyle //to make the date on the following format
                {
                    Format = "dd/MM/yyyy"
                }
            });

            dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Customer",
                DataPropertyName = "DisplayCustomerText"
            });

            dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Estimated Delivery",
                DataPropertyName = "EstimatedDeliveryDate",
                DefaultCellStyle = new DataGridViewCellStyle //to make the date on the following format
                {
                    Format = "dd/MM/yyyy"
                }
            });

            dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Status",
                DataPropertyName = "Status"
            });

            dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Delivered On",
                DataPropertyName = "DeliveredOnDate",
                DefaultCellStyle = new DataGridViewCellStyle //to make the date on the following format
                {
                    Format = "dd/MM/yyyy"
                }
            });

            dgvOrders.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Total ($)",
                DataPropertyName = "TotalPrice"
            });
        }

        private void FormatOrdersItemsGrid()
        {
            dgvOrderItems.AutoGenerateColumns = false;
            dgvOrderItems.Columns.Clear();

            dgvOrderItems.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Product",
                DataPropertyName = "DisplayProuductText"
            });
            dgvOrderItems.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Quantity",
                DataPropertyName = "Quantity"
            });
        }

    }
}
