﻿using Business_Inventory_Management_System.Properties;

namespace Business_Inventory_Management_System
{
    partial class FormCustomerInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCustomerInfo));
            lbllFirstName = new Label();
            tbxFirstName = new TextBox();
            tbxPhoneNumber = new TextBox();
            lblPhoneNumber = new Label();
            tbxEmail = new TextBox();
            lblEmail = new Label();
            tbxAddress = new TextBox();
            lblAddress = new Label();
            tbxLastName = new TextBox();
            lblLastName = new Label();
            btnCancel = new Button();
            btnConfirm = new Button();
            tbxID = new TextBox();
            lblID = new Label();
            lblMsg = new Label();
            lblEmailRequired = new Label();
            lblPhoneNameRequired = new Label();
            lblLastNameRequired = new Label();
            lblFirstNameRequired = new Label();
            SuspendLayout();
            // 
            // lbllFirstName
            // 
            lbllFirstName.AutoSize = true;
            lbllFirstName.Font = new Font("Segoe UI", 10F);
            lbllFirstName.ForeColor = SystemColors.ControlLightLight;
            lbllFirstName.Location = new Point(50, 64);
            lbllFirstName.Name = "lbllFirstName";
            lbllFirstName.Size = new Size(92, 23);
            lbllFirstName.TabIndex = 0;
            lbllFirstName.Text = "First Name";
            // 
            // tbxFirstName
            // 
            tbxFirstName.Location = new Point(144, 64);
            tbxFirstName.Name = "tbxFirstName";
            tbxFirstName.PlaceholderText = "Enter first name";
            tbxFirstName.Size = new Size(210, 27);
            tbxFirstName.TabIndex = 1;
            tbxFirstName.TextChanged += tbxFirstName_TextChanged;
            // 
            // tbxPhoneNumber
            // 
            tbxPhoneNumber.Location = new Point(144, 154);
            tbxPhoneNumber.Name = "tbxPhoneNumber";
            tbxPhoneNumber.PlaceholderText = "Enter phone number";
            tbxPhoneNumber.Size = new Size(210, 27);
            tbxPhoneNumber.TabIndex = 3;
            tbxPhoneNumber.TextChanged += tbxPhoneNumber_TextChanged;
            // 
            // lblPhoneNumber
            // 
            lblPhoneNumber.AutoSize = true;
            lblPhoneNumber.Font = new Font("Segoe UI", 10F);
            lblPhoneNumber.ForeColor = SystemColors.ControlLightLight;
            lblPhoneNumber.Location = new Point(14, 154);
            lblPhoneNumber.Name = "lblPhoneNumber";
            lblPhoneNumber.Size = new Size(127, 23);
            lblPhoneNumber.TabIndex = 2;
            lblPhoneNumber.Text = "Phone Number";
            // 
            // tbxEmail
            // 
            tbxEmail.Location = new Point(144, 199);
            tbxEmail.Name = "tbxEmail";
            tbxEmail.PlaceholderText = "Enter Email";
            tbxEmail.Size = new Size(210, 27);
            tbxEmail.TabIndex = 5;
            tbxEmail.TextChanged += tbxEmail_TextChanged;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 10F);
            lblEmail.ForeColor = SystemColors.ControlLightLight;
            lblEmail.Location = new Point(90, 199);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(51, 23);
            lblEmail.TabIndex = 4;
            lblEmail.Text = "Email";
            // 
            // tbxAddress
            // 
            tbxAddress.Location = new Point(144, 244);
            tbxAddress.Name = "tbxAddress";
            tbxAddress.PlaceholderText = "Enter address";
            tbxAddress.Size = new Size(210, 27);
            tbxAddress.TabIndex = 7;
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Segoe UI", 10F);
            lblAddress.ForeColor = SystemColors.ControlLightLight;
            lblAddress.Location = new Point(71, 244);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(70, 23);
            lblAddress.TabIndex = 6;
            lblAddress.Text = "Address";
            // 
            // tbxLastName
            // 
            tbxLastName.Location = new Point(144, 109);
            tbxLastName.Name = "tbxLastName";
            tbxLastName.PlaceholderText = "Enter last name";
            tbxLastName.Size = new Size(210, 27);
            tbxLastName.TabIndex = 9;
            tbxLastName.TextChanged += tbxLastName_TextChanged;
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Font = new Font("Segoe UI", 10F);
            lblLastName.ForeColor = SystemColors.ControlLightLight;
            lblLastName.Location = new Point(50, 109);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(91, 23);
            lblLastName.TabIndex = 8;
            lblLastName.Text = "Last Name";
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(18, 335);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(167, 37);
            btnCancel.TabIndex = 15;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnConfirm
            // 
            btnConfirm.BackColor = Color.DarkSlateGray;
            btnConfirm.Enabled = false;
            btnConfirm.FlatAppearance.BorderColor = Color.Black;
            btnConfirm.FlatStyle = FlatStyle.Flat;
            btnConfirm.ForeColor = Color.Black;
            btnConfirm.Location = new Point(200, 335);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(167, 37);
            btnConfirm.TabIndex = 14;
            btnConfirm.Text = "Confirm";
            btnConfirm.UseVisualStyleBackColor = false;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // tbxID
            // 
            tbxID.Location = new Point(144, 19);
            tbxID.Name = "tbxID";
            tbxID.PlaceholderText = "Enter ID";
            tbxID.Size = new Size(210, 27);
            tbxID.TabIndex = 25;
            tbxID.Visible = false;
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Font = new Font("Segoe UI", 10F);
            lblID.ForeColor = SystemColors.ControlLightLight;
            lblID.Location = new Point(114, 21);
            lblID.Name = "lblID";
            lblID.Size = new Size(27, 23);
            lblID.TabIndex = 24;
            lblID.Text = "ID";
            lblID.Visible = false;
            // 
            // lblMsg
            // 
            lblMsg.Font = new Font("Segoe UI", 10F);
            lblMsg.ForeColor = Color.Gold;
            lblMsg.Location = new Point(23, 285);
            lblMsg.Name = "lblMsg";
            lblMsg.Size = new Size(349, 29);
            lblMsg.TabIndex = 26;
            lblMsg.Text = "Msg";
            lblMsg.TextAlign = ContentAlignment.MiddleCenter;
            lblMsg.Visible = false;
            // 
            // lblEmailRequired
            // 
            lblEmailRequired.AutoSize = true;
            lblEmailRequired.Font = new Font("Segoe UI", 12F);
            lblEmailRequired.ForeColor = Color.Gold;
            lblEmailRequired.Location = new Point(77, 199);
            lblEmailRequired.Name = "lblEmailRequired";
            lblEmailRequired.Size = new Size(20, 28);
            lblEmailRequired.TabIndex = 45;
            lblEmailRequired.Text = "*";
            // 
            // lblPhoneNameRequired
            // 
            lblPhoneNameRequired.AutoSize = true;
            lblPhoneNameRequired.Font = new Font("Segoe UI", 12F);
            lblPhoneNameRequired.ForeColor = Color.Gold;
            lblPhoneNameRequired.Location = new Point(1, 154);
            lblPhoneNameRequired.Name = "lblPhoneNameRequired";
            lblPhoneNameRequired.Size = new Size(20, 28);
            lblPhoneNameRequired.TabIndex = 46;
            lblPhoneNameRequired.Text = "*";
            // 
            // lblLastNameRequired
            // 
            lblLastNameRequired.AutoSize = true;
            lblLastNameRequired.Font = new Font("Segoe UI", 12F);
            lblLastNameRequired.ForeColor = Color.Gold;
            lblLastNameRequired.Location = new Point(37, 109);
            lblLastNameRequired.Name = "lblLastNameRequired";
            lblLastNameRequired.Size = new Size(20, 28);
            lblLastNameRequired.TabIndex = 47;
            lblLastNameRequired.Text = "*";
            // 
            // lblFirstNameRequired
            // 
            lblFirstNameRequired.AutoSize = true;
            lblFirstNameRequired.Font = new Font("Segoe UI", 12F);
            lblFirstNameRequired.ForeColor = Color.Gold;
            lblFirstNameRequired.Location = new Point(37, 64);
            lblFirstNameRequired.Name = "lblFirstNameRequired";
            lblFirstNameRequired.Size = new Size(20, 28);
            lblFirstNameRequired.TabIndex = 48;
            lblFirstNameRequired.Text = "*";
            // 
            // FormCustomerInfo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(387, 389);
            Controls.Add(lblEmail);
            Controls.Add(lblPhoneNumber);
            Controls.Add(lblLastName);
            Controls.Add(lbllFirstName);
            Controls.Add(lblFirstNameRequired);
            Controls.Add(lblLastNameRequired);
            Controls.Add(lblPhoneNameRequired);
            Controls.Add(lblEmailRequired);
            Controls.Add(lblMsg);
            Controls.Add(tbxID);
            Controls.Add(lblID);
            Controls.Add(btnCancel);
            Controls.Add(btnConfirm);
            Controls.Add(tbxLastName);
            Controls.Add(tbxAddress);
            Controls.Add(lblAddress);
            Controls.Add(tbxEmail);
            Controls.Add(tbxPhoneNumber);
            Controls.Add(tbxFirstName);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FormCustomerInfo";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Customer";
            Load += FormCustomerInfo_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbllFirstName;
        private TextBox tbxFirstName;
        private TextBox tbxPhoneNumber;
        private Label lblPhoneNumber;
        private TextBox tbxEmail;
        private Label lblEmail;
        private TextBox tbxAddress;
        private Label lblAddress;
        private TextBox tbxLastName;
        private Label lblLastName;
        private Button btnCancel;
        private Button btnConfirm;
        private Label lblPasswordsNotMatch;
        private TextBox tbxID;
        private Label lblID;
        private Label lblMsg;
        private Label lblEmailRequired;
        private Label lblPhoneNameRequired;
        private Label lblLastNameRequired;
        private Label lblFirstNameRequired;
    }
}