﻿namespace Business_Inventory_Management_System
{
    partial class FormOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            dgvOrders = new DataGridView();
            panelOptions = new Panel();
            btnReset = new Button();
            btnSearch = new Button();
            btnDelete = new Button();
            btnEdit = new Button();
            btnAdd = new Button();
            lblOrders = new Label();
            dgvOrderItems = new DataGridView();
            lblOrderItems = new Label();
            lblNoSelectedOrder = new Label();
            lblEmptyOrdersList = new Label();
            panelOrders = new Panel();
            lblNoResults = new Label();
            panelOrdersItem = new Panel();
            ((System.ComponentModel.ISupportInitialize)dgvOrders).BeginInit();
            panelOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvOrderItems).BeginInit();
            panelOrders.SuspendLayout();
            panelOrdersItem.SuspendLayout();
            SuspendLayout();
            // 
            // dgvOrders
            // 
            dgvOrders.AllowUserToAddRows = false;
            dgvOrders.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvOrders.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvOrders.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvOrders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvOrders.DefaultCellStyle = dataGridViewCellStyle2;
            dgvOrders.Dock = DockStyle.Fill;
            dgvOrders.Location = new Point(0, 0);
            dgvOrders.Name = "dgvOrders";
            dgvOrders.ReadOnly = true;
            dgvOrders.RowHeadersVisible = false;
            dgvOrders.RowHeadersWidth = 51;
            dgvOrders.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvOrders.Size = new Size(600, 356);
            dgvOrders.TabIndex = 5;
            dgvOrders.SelectionChanged += dgvOrders_SelectionChanged;
            // 
            // panelOptions
            // 
            panelOptions.Anchor = AnchorStyles.Right;
            panelOptions.Controls.Add(btnReset);
            panelOptions.Controls.Add(btnSearch);
            panelOptions.Controls.Add(btnDelete);
            panelOptions.Controls.Add(btnEdit);
            panelOptions.Controls.Add(btnAdd);
            panelOptions.Location = new Point(618, 51);
            panelOptions.Name = "panelOptions";
            panelOptions.Size = new Size(148, 545);
            panelOptions.TabIndex = 6;
            // 
            // btnReset
            // 
            btnReset.Font = new Font("Segoe UI", 11F);
            btnReset.ForeColor = Color.Black;
            btnReset.Location = new Point(0, 284);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(148, 53);
            btnReset.TabIndex = 4;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // btnSearch
            // 
            btnSearch.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSearch.BackColor = Color.LightSeaGreen;
            btnSearch.FlatAppearance.BorderColor = Color.Black;
            btnSearch.FlatStyle = FlatStyle.Popup;
            btnSearch.Font = new Font("Segoe UI", 11F);
            btnSearch.Location = new Point(0, 224);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(148, 53);
            btnSearch.TabIndex = 3;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnDelete.BackColor = Color.DarkSlateGray;
            btnDelete.Enabled = false;
            btnDelete.FlatAppearance.BorderColor = Color.Black;
            btnDelete.FlatStyle = FlatStyle.Popup;
            btnDelete.Font = new Font("Segoe UI", 11F);
            btnDelete.Location = new Point(0, 120);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(148, 53);
            btnDelete.TabIndex = 2;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnEdit
            // 
            btnEdit.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnEdit.BackColor = Color.DarkSlateGray;
            btnEdit.Enabled = false;
            btnEdit.FlatAppearance.BorderColor = Color.Black;
            btnEdit.FlatStyle = FlatStyle.Popup;
            btnEdit.Font = new Font("Segoe UI", 11F);
            btnEdit.Location = new Point(0, 61);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(148, 53);
            btnEdit.TabIndex = 1;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.LightSeaGreen;
            btnAdd.Dock = DockStyle.Top;
            btnAdd.FlatAppearance.BorderColor = Color.Black;
            btnAdd.FlatStyle = FlatStyle.Popup;
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.Location = new Point(0, 0);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(148, 53);
            btnAdd.TabIndex = 0;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // lblOrders
            // 
            lblOrders.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblOrders.ForeColor = SystemColors.ButtonHighlight;
            lblOrders.Location = new Point(10, 7);
            lblOrders.Name = "lblOrders";
            lblOrders.Size = new Size(97, 32);
            lblOrders.TabIndex = 8;
            lblOrders.Text = "Orders";
            // 
            // dgvOrderItems
            // 
            dgvOrderItems.AllowUserToAddRows = false;
            dgvOrderItems.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dgvOrderItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvOrderItems.BackgroundColor = Color.Gainsboro;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgvOrderItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgvOrderItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Window;
            dataGridViewCellStyle4.Font = new Font("Microsoft YaHei UI", 11F);
            dataGridViewCellStyle4.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            dgvOrderItems.DefaultCellStyle = dataGridViewCellStyle4;
            dgvOrderItems.Location = new Point(0, -2);
            dgvOrderItems.Name = "dgvOrderItems";
            dgvOrderItems.ReadOnly = true;
            dgvOrderItems.RowHeadersVisible = false;
            dgvOrderItems.RowHeadersWidth = 51;
            dgvOrderItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvOrderItems.Size = new Size(756, 156);
            dgvOrderItems.TabIndex = 9;
            // 
            // lblOrderItems
            // 
            lblOrderItems.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblOrderItems.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            lblOrderItems.ForeColor = SystemColors.ButtonHighlight;
            lblOrderItems.Location = new Point(10, 407);
            lblOrderItems.Name = "lblOrderItems";
            lblOrderItems.Size = new Size(160, 32);
            lblOrderItems.TabIndex = 10;
            lblOrderItems.Text = "Order Items";
            // 
            // lblNoSelectedOrder
            // 
            lblNoSelectedOrder.Anchor = AnchorStyles.None;
            lblNoSelectedOrder.BackColor = Color.Gainsboro;
            lblNoSelectedOrder.Font = new Font("Segoe UI", 11F);
            lblNoSelectedOrder.ForeColor = Color.Teal;
            lblNoSelectedOrder.Location = new Point(223, 68);
            lblNoSelectedOrder.Name = "lblNoSelectedOrder";
            lblNoSelectedOrder.Size = new Size(321, 64);
            lblNoSelectedOrder.TabIndex = 11;
            lblNoSelectedOrder.Text = "Please, select an order from the list above to show its items";
            lblNoSelectedOrder.Visible = false;
            // 
            // lblEmptyOrdersList
            // 
            lblEmptyOrdersList.Anchor = AnchorStyles.None;
            lblEmptyOrdersList.BackColor = Color.Gainsboro;
            lblEmptyOrdersList.Font = new Font("Segoe UI", 11F);
            lblEmptyOrdersList.ForeColor = Color.Teal;
            lblEmptyOrdersList.Location = new Point(146, 151);
            lblEmptyOrdersList.Name = "lblEmptyOrdersList";
            lblEmptyOrdersList.Size = new Size(321, 64);
            lblEmptyOrdersList.TabIndex = 7;
            lblEmptyOrdersList.Text = "There are no orders yet.\nPlease add a new order to the list.";
            lblEmptyOrdersList.Visible = false;
            // 
            // panelOrders
            // 
            panelOrders.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panelOrders.Controls.Add(lblNoResults);
            panelOrders.Controls.Add(lblEmptyOrdersList);
            panelOrders.Controls.Add(dgvOrders);
            panelOrders.Location = new Point(10, 39);
            panelOrders.Name = "panelOrders";
            panelOrders.Size = new Size(600, 356);
            panelOrders.TabIndex = 12;
            // 
            // lblNoResults
            // 
            lblNoResults.Anchor = AnchorStyles.None;
            lblNoResults.BackColor = Color.Gainsboro;
            lblNoResults.Font = new Font("Segoe UI", 11F);
            lblNoResults.ForeColor = Color.Teal;
            lblNoResults.Location = new Point(156, 165);
            lblNoResults.Name = "lblNoResults";
            lblNoResults.Size = new Size(263, 28);
            lblNoResults.TabIndex = 9;
            lblNoResults.Text = "There are no matching results";
            lblNoResults.Visible = false;
            // 
            // panelOrdersItem
            // 
            panelOrdersItem.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panelOrdersItem.Controls.Add(lblNoSelectedOrder);
            panelOrdersItem.Controls.Add(dgvOrderItems);
            panelOrdersItem.Location = new Point(10, 442);
            panelOrdersItem.Name = "panelOrdersItem";
            panelOrdersItem.Size = new Size(756, 154);
            panelOrdersItem.TabIndex = 13;
            // 
            // FormOrders
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(772, 608);
            Controls.Add(panelOrdersItem);
            Controls.Add(panelOrders);
            Controls.Add(lblOrderItems);
            Controls.Add(lblOrders);
            Controls.Add(panelOptions);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormOrders";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormOrders";
            FormClosing += FormOrders_FormClosing;
            Load += FormOrders_Load;
            ((System.ComponentModel.ISupportInitialize)dgvOrders).EndInit();
            panelOptions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvOrderItems).EndInit();
            panelOrders.ResumeLayout(false);
            panelOrdersItem.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private DataGridView dgvOrders;
        private Panel panelOptions;
        private Button btnDelete;
        private Button btnEdit;
        private Button btnAdd;
        private Button btnReset;
        private Button btnSearch;
        private Label lblOrders;
        private DataGridView dgvOrderItems;
        private Label lblOrderItems;
        private Label lblNoSelectedOrder;
        private Label lblEmptyOrdersList;
        private Panel panelOrders;
        private Panel panelOrdersItem;
        private Label lblNoResults;
    }
}