﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Business_Inventory_Management_System
{
    public class BestSellingProduct
    {
        public string DisplayText => $"{Product.DisplayCode} | {Product.Name} | {Product.Category} | {Product.Price} $";

        public Product Product { get; set; }
        public int TotalSoldQuantity { get; set; }

        public static List<BestSellingProduct> BuildBestSellingProducts()
        {
            Dictionary<Product, int> productSales =
                new Dictionary<Product, int>();

            int totalQuantitySold = 0;

            // 1️- Sum quantities for each product across all orders
            foreach (Order order in FormOrders.Orders)
            {
                foreach (OrderItem item in order.Items)
                {
                    if (!productSales.ContainsKey(item.Product))
                        productSales[item.Product] = 0;

                    productSales[item.Product] += item.Quantity;
                    totalQuantitySold += item.Quantity;
                }
            }

            // if no sales at all
            if (productSales.Count == 0)
                return new List<BestSellingProduct>();

            // 2️- Calculate average selling quantity
            double averageSelling =
                (double)totalQuantitySold / productSales.Count;

            // 3️- Keep products above average
            List<BestSellingProduct> bestSelling = new List<BestSellingProduct>();

            foreach (var kvp in productSales)
            {
                if (kvp.Value > averageSelling)
                {
                    bestSelling.Add(new BestSellingProduct
                    {
                        Product = kvp.Key,
                        TotalSoldQuantity = kvp.Value
                    });
                }
            }

            return bestSelling;
        }
    }
}
