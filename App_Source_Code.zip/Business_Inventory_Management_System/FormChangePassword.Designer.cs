﻿namespace Business_Inventory_Management_System
{
    partial class FormChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblImportantMessage = new Label();
            lblPasswordsNotMatch = new Label();
            btnShowOrHideConfirmPass = new Button();
            btnShowOrHideNewPass = new Button();
            tbxConfirmPassword = new TextBox();
            lblConfirmPassword = new Label();
            tbxNewPassword = new TextBox();
            tbxOldPassword = new TextBox();
            lblNewPassword = new Label();
            lblOldPassword = new Label();
            btnConfirm = new Button();
            lblPasswordWrong = new Label();
            lblSuccessfulSaved = new Label();
            btnOlsPassword = new Button();
            SuspendLayout();
            // 
            // lblImportantMessage
            // 
            lblImportantMessage.Anchor = AnchorStyles.None;
            lblImportantMessage.AutoSize = true;
            lblImportantMessage.BackColor = Color.Gray;
            lblImportantMessage.Font = new Font("MS Reference Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblImportantMessage.ForeColor = Color.PaleTurquoise;
            lblImportantMessage.Location = new Point(177, 302);
            lblImportantMessage.Name = "lblImportantMessage";
            lblImportantMessage.Size = new Size(496, 44);
            lblImportantMessage.TabIndex = 23;
            lblImportantMessage.Text = "Important: Please remember this password.\nFor security reasons, it cannot be recovered if forgotten.";
            // 
            // lblPasswordsNotMatch
            // 
            lblPasswordsNotMatch.Anchor = AnchorStyles.None;
            lblPasswordsNotMatch.AutoSize = true;
            lblPasswordsNotMatch.Font = new Font("Segoe UI", 8F);
            lblPasswordsNotMatch.ForeColor = Color.Gold;
            lblPasswordsNotMatch.Location = new Point(594, 243);
            lblPasswordsNotMatch.Name = "lblPasswordsNotMatch";
            lblPasswordsNotMatch.Size = new Size(164, 19);
            lblPasswordsNotMatch.TabIndex = 22;
            lblPasswordsNotMatch.Text = "Passwords do not match!";
            lblPasswordsNotMatch.Visible = false;
            // 
            // btnShowOrHideConfirmPass
            // 
            btnShowOrHideConfirmPass.Anchor = AnchorStyles.None;
            btnShowOrHideConfirmPass.BackColor = Color.DarkGray;
            btnShowOrHideConfirmPass.Enabled = false;
            btnShowOrHideConfirmPass.FlatAppearance.BorderSize = 0;
            btnShowOrHideConfirmPass.FlatStyle = FlatStyle.Flat;
            btnShowOrHideConfirmPass.Image = Properties.Resources.showPasswordIcon;
            btnShowOrHideConfirmPass.Location = new Point(558, 240);
            btnShowOrHideConfirmPass.Name = "btnShowOrHideConfirmPass";
            btnShowOrHideConfirmPass.Size = new Size(30, 25);
            btnShowOrHideConfirmPass.TabIndex = 21;
            btnShowOrHideConfirmPass.UseVisualStyleBackColor = false;
            btnShowOrHideConfirmPass.Click += btnShowOrHideConfirmPass_Click;
            // 
            // btnShowOrHideNewPass
            // 
            btnShowOrHideNewPass.Anchor = AnchorStyles.None;
            btnShowOrHideNewPass.BackColor = Color.DarkGray;
            btnShowOrHideNewPass.FlatAppearance.BorderSize = 0;
            btnShowOrHideNewPass.FlatStyle = FlatStyle.Flat;
            btnShowOrHideNewPass.Image = Properties.Resources.showPasswordIcon;
            btnShowOrHideNewPass.Location = new Point(558, 181);
            btnShowOrHideNewPass.Name = "btnShowOrHideNewPass";
            btnShowOrHideNewPass.Size = new Size(30, 25);
            btnShowOrHideNewPass.TabIndex = 20;
            btnShowOrHideNewPass.UseVisualStyleBackColor = false;
            btnShowOrHideNewPass.Click += btnShowOrHideNewPass_Click;
            // 
            // tbxConfirmPassword
            // 
            tbxConfirmPassword.Anchor = AnchorStyles.None;
            tbxConfirmPassword.BackColor = Color.DarkGray;
            tbxConfirmPassword.BorderStyle = BorderStyle.FixedSingle;
            tbxConfirmPassword.Enabled = false;
            tbxConfirmPassword.Font = new Font("Segoe UI", 9F);
            tbxConfirmPassword.Location = new Point(262, 239);
            tbxConfirmPassword.Name = "tbxConfirmPassword";
            tbxConfirmPassword.PasswordChar = '*';
            tbxConfirmPassword.PlaceholderText = "Enter confirm password";
            tbxConfirmPassword.Size = new Size(290, 27);
            tbxConfirmPassword.TabIndex = 19;
            tbxConfirmPassword.TextChanged += tbxConfirmPassword_TextChanged;
            // 
            // lblConfirmPassword
            // 
            lblConfirmPassword.Anchor = AnchorStyles.None;
            lblConfirmPassword.AutoSize = true;
            lblConfirmPassword.Font = new Font("Segoe UI", 10F);
            lblConfirmPassword.ForeColor = SystemColors.ControlLightLight;
            lblConfirmPassword.Location = new Point(111, 241);
            lblConfirmPassword.Name = "lblConfirmPassword";
            lblConfirmPassword.Size = new Size(146, 23);
            lblConfirmPassword.TabIndex = 18;
            lblConfirmPassword.Text = "Confirm Password";
            // 
            // tbxNewPassword
            // 
            tbxNewPassword.Anchor = AnchorStyles.None;
            tbxNewPassword.BorderStyle = BorderStyle.FixedSingle;
            tbxNewPassword.Font = new Font("Segoe UI", 9F);
            tbxNewPassword.Location = new Point(262, 180);
            tbxNewPassword.Name = "tbxNewPassword";
            tbxNewPassword.PasswordChar = '*';
            tbxNewPassword.PlaceholderText = "Enter new password";
            tbxNewPassword.Size = new Size(290, 27);
            tbxNewPassword.TabIndex = 17;
            tbxNewPassword.TextChanged += tbxNewPassword_TextChanged;
            // 
            // tbxOldPassword
            // 
            tbxOldPassword.Anchor = AnchorStyles.None;
            tbxOldPassword.BorderStyle = BorderStyle.FixedSingle;
            tbxOldPassword.Font = new Font("Segoe UI", 9F);
            tbxOldPassword.Location = new Point(262, 125);
            tbxOldPassword.Name = "tbxOldPassword";
            tbxOldPassword.PasswordChar = '*';
            tbxOldPassword.PlaceholderText = "Enter current password";
            tbxOldPassword.Size = new Size(290, 27);
            tbxOldPassword.TabIndex = 16;
            tbxOldPassword.TextChanged += tbxOldPassword_TextChanged;
            // 
            // lblNewPassword
            // 
            lblNewPassword.Anchor = AnchorStyles.None;
            lblNewPassword.AutoSize = true;
            lblNewPassword.Font = new Font("Segoe UI", 10F);
            lblNewPassword.ForeColor = SystemColors.ControlLightLight;
            lblNewPassword.Location = new Point(137, 182);
            lblNewPassword.Name = "lblNewPassword";
            lblNewPassword.Size = new Size(119, 23);
            lblNewPassword.TabIndex = 15;
            lblNewPassword.Text = "New Password";
            // 
            // lblOldPassword
            // 
            lblOldPassword.Anchor = AnchorStyles.None;
            lblOldPassword.AutoSize = true;
            lblOldPassword.Font = new Font("Segoe UI", 10F);
            lblOldPassword.ForeColor = SystemColors.ControlLightLight;
            lblOldPassword.Location = new Point(145, 127);
            lblOldPassword.Name = "lblOldPassword";
            lblOldPassword.Size = new Size(112, 23);
            lblOldPassword.TabIndex = 14;
            lblOldPassword.Text = "Old Password";
            // 
            // btnConfirm
            // 
            btnConfirm.Anchor = AnchorStyles.None;
            btnConfirm.BackColor = Color.DarkSlateGray;
            btnConfirm.Enabled = false;
            btnConfirm.FlatAppearance.BorderColor = Color.Black;
            btnConfirm.FlatStyle = FlatStyle.Popup;
            btnConfirm.ForeColor = Color.Black;
            btnConfirm.Location = new Point(292, 419);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(196, 53);
            btnConfirm.TabIndex = 12;
            btnConfirm.Text = "Confirm";
            btnConfirm.UseVisualStyleBackColor = false;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // lblPasswordWrong
            // 
            lblPasswordWrong.Anchor = AnchorStyles.None;
            lblPasswordWrong.AutoSize = true;
            lblPasswordWrong.Font = new Font("Segoe UI", 8F);
            lblPasswordWrong.ForeColor = Color.Gold;
            lblPasswordWrong.Location = new Point(594, 129);
            lblPasswordWrong.Name = "lblPasswordWrong";
            lblPasswordWrong.Size = new Size(129, 19);
            lblPasswordWrong.TabIndex = 24;
            lblPasswordWrong.Text = "Incorrect password!";
            lblPasswordWrong.Visible = false;
            // 
            // lblSuccessfulSaved
            // 
            lblSuccessfulSaved.Anchor = AnchorStyles.None;
            lblSuccessfulSaved.BackColor = Color.Gray;
            lblSuccessfulSaved.Font = new Font("Segoe UI", 10F);
            lblSuccessfulSaved.ForeColor = Color.LawnGreen;
            lblSuccessfulSaved.Location = new Point(163, 365);
            lblSuccessfulSaved.Name = "lblSuccessfulSaved";
            lblSuccessfulSaved.Size = new Size(456, 48);
            lblSuccessfulSaved.TabIndex = 57;
            lblSuccessfulSaved.Text = "Your password has been updated successfully.";
            lblSuccessfulSaved.TextAlign = ContentAlignment.MiddleCenter;
            lblSuccessfulSaved.Visible = false;
            // 
            // btnOlsPassword
            // 
            btnOlsPassword.Anchor = AnchorStyles.None;
            btnOlsPassword.BackColor = Color.DarkGray;
            btnOlsPassword.FlatAppearance.BorderSize = 0;
            btnOlsPassword.FlatStyle = FlatStyle.Flat;
            btnOlsPassword.Image = Properties.Resources.showPasswordIcon;
            btnOlsPassword.Location = new Point(558, 126);
            btnOlsPassword.Name = "btnOlsPassword";
            btnOlsPassword.Size = new Size(30, 25);
            btnOlsPassword.TabIndex = 58;
            btnOlsPassword.UseVisualStyleBackColor = false;
            btnOlsPassword.Click += btnOlsPassword_Click;
            // 
            // FormChangePassword
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(796, 561);
            Controls.Add(btnOlsPassword);
            Controls.Add(lblSuccessfulSaved);
            Controls.Add(lblPasswordWrong);
            Controls.Add(lblImportantMessage);
            Controls.Add(lblPasswordsNotMatch);
            Controls.Add(btnShowOrHideConfirmPass);
            Controls.Add(btnShowOrHideNewPass);
            Controls.Add(tbxConfirmPassword);
            Controls.Add(lblConfirmPassword);
            Controls.Add(tbxNewPassword);
            Controls.Add(tbxOldPassword);
            Controls.Add(lblNewPassword);
            Controls.Add(lblOldPassword);
            Controls.Add(btnConfirm);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FormChangePassword";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormChangePasswors";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblImportantMessage;
        private Label lblPasswordsNotMatch;
        private Button btnShowOrHideConfirmPass;
        private Button btnShowOrHideNewPass;
        private TextBox tbxConfirmPassword;
        private Label lblConfirmPassword;
        private TextBox tbxNewPassword;
        private TextBox tbxOldPassword;
        private Label lblNewPassword;
        private Label lblOldPassword;
        private Button btnConfirm;
        private Label lblPasswordWrong;
        private Label lblSuccessfulSaved;
        private Button btnOlsPassword;
    }
}