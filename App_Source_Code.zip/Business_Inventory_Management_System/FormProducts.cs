﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormProducts : Form
    {
        // Change the property definition for ID to make the setter accessible
        public static long ID { get; set; }
        public static string Name { get; set; }
        public static string Category { get; set; }
        public static decimal Price { get; set; }
        public static int StockQuantity { get; set; }
        public static string Description { get; set; }

        public static BindingList<Product> Products =
            Helpers.LoadJsonToBindingList<Product>("Products.json");
        public FormProducts()
        {
            InitializeComponent();
            Product.InitializeIDSeed(Products);
        }

        private void FormProducts_Load(object sender, EventArgs e)
        {
            dgvProducts.DataSource = Products;
            dgvProducts.Columns["ID"].Visible = false;
            dgvProducts.Columns["DisplayText"].Visible = false;
            dgvProducts.Columns["DisplayCode"].HeaderText = "ID";
            dgvProducts.Columns["Name"].HeaderText = "Product Name";
            dgvProducts.Columns["Price"].HeaderText = "Price ($)";
            UpdateLabelOnEmptyList();
            UpdateEditAndDeleteButtons();
            lblNoResults.Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e) //Done
        {
            using FormProductInfo frm = new FormProductInfo('A'); //Add Mode
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;

            Products.Add(new Product(Name, Price, StockQuantity, Category, Description));
            UpdateLabelOnEmptyList();
        }

        private void btnEdit_Click(object sender, EventArgs e) //Done
        {
            Product p = dgvProducts.CurrentRow.DataBoundItem as Product;
            using FormProductInfo frm = new FormProductInfo('E', p); //Edite mode
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;

            p.Price = Price;
            p.Name = Name;
            p.StockQuantity = StockQuantity;
            p.Category = Category;
            p.Description = Description;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
            $"Are you sure you want to delete product with ID({(dgvProducts.CurrentRow.DataBoundItem as Product).DisplayCode})?\n\nThis action cannot be undone.",
            "Confirm Delete",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            Product p = dgvProducts.CurrentRow.DataBoundItem as Product;
            Products.Remove(p);

            if (dgvProducts.DataSource is BindingList<Product> currentList &&
            currentList != Products) //delete from dgv if the list is a temp searching 
            {
                currentList.Remove(p);
            }
            UpdateLabelOnEmptyList();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using FormProductInfo frm = new FormProductInfo('S'); //Search mode
            DialogResult result = frm.ShowDialog();

            if (result != DialogResult.OK) return;


            BindingList<Product> temp = new BindingList<Product>();
            foreach (Product p in Products)
            {
                bool match = true;

                // STRING filters
                if (!string.IsNullOrWhiteSpace(Name) &&
                    !p.Name.Contains(Name, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (!string.IsNullOrWhiteSpace(Category) &&
                    !p.Category.Contains(Category, StringComparison.OrdinalIgnoreCase))
                    match = false;

                if (!string.IsNullOrWhiteSpace(Description) &&
                    !p.Description.Contains(Description, StringComparison.OrdinalIgnoreCase))
                    match = false;

                // NUMERIC filters
                if (ID > 0 && p.ID != ID)
                    match = false;

                if (Price > 0 && p.Price != Price)
                    match = false;

                if (StockQuantity > 0 && p.StockQuantity != StockQuantity)
                    match = false;

                if (match)
                    temp.Add(p);
            }

            if (temp.Count == 0)
                lblNoResults.Visible = true;
            else lblNoResults.Visible = false;
            
            dgvProducts.DataSource = temp;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lblNoResults.Visible = false;
            dgvProducts.DataSource = Products;
        }

        private void dgvProducts_SelectionChanged(object sender, EventArgs e)
        {
            UpdateEditAndDeleteButtons();
        }

        private void FormProducts_FormClosing(object sender, FormClosingEventArgs e)
        {
            Helpers.SaveBindingListToJson<Product>(Products, "Products.json");
        }

        void UpdateLabelOnEmptyList()
        {
            if (Products.Count == 0)
                lblEmptyProductsList.Visible = true;
            else
                lblEmptyProductsList.Visible = false;
        }

        void UpdateEditAndDeleteButtons()
        {
            if (dgvProducts.CurrentRow != null)
            {
                Helpers.AvtivateButton(btnEdit, Color.LightSeaGreen);
                Helpers.AvtivateButton(btnDelete, Color.LightSeaGreen);
                return;
            }
            Helpers.DeavtivateButton(btnEdit, Color.DarkSlateGray);
            Helpers.DeavtivateButton(btnDelete, Color.DarkSlateGray);
        }

    }
}
