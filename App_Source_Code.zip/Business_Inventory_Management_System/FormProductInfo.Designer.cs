﻿namespace Business_Inventory_Management_System
{
    partial class FormProductInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormProductInfo));
            lblID = new Label();
            btnCancel = new Button();
            btnConfirm = new Button();
            tbxCategory = new TextBox();
            tbxDescription = new TextBox();
            lblDescription = new Label();
            lblEmail = new Label();
            lblPrice = new Label();
            tbxName = new TextBox();
            lbllName = new Label();
            lblCategory = new Label();
            lblMsg = new Label();
            nudStockQuantity = new NumericUpDown();
            nudPrice = new NumericUpDown();
            tbxID = new TextBox();
            lblNameRequired = new Label();
            lblPriceRequired = new Label();
            lblStockQuantityRequired = new Label();
            ((System.ComponentModel.ISupportInitialize)nudStockQuantity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudPrice).BeginInit();
            SuspendLayout();
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Font = new Font("Segoe UI", 10F);
            lblID.ForeColor = SystemColors.ControlLightLight;
            lblID.Location = new Point(107, 22);
            lblID.Name = "lblID";
            lblID.Size = new Size(27, 23);
            lblID.TabIndex = 38;
            lblID.Text = "ID";
            lblID.Visible = false;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(16, 336);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(167, 37);
            btnCancel.TabIndex = 37;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnConfirm
            // 
            btnConfirm.BackColor = Color.DarkSlateGray;
            btnConfirm.Enabled = false;
            btnConfirm.FlatAppearance.BorderColor = Color.Black;
            btnConfirm.FlatStyle = FlatStyle.Flat;
            btnConfirm.ForeColor = Color.Black;
            btnConfirm.Location = new Point(198, 336);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(167, 37);
            btnConfirm.TabIndex = 36;
            btnConfirm.Text = "Confirm";
            btnConfirm.UseVisualStyleBackColor = false;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // tbxCategory
            // 
            tbxCategory.Location = new Point(137, 110);
            tbxCategory.Name = "tbxCategory";
            tbxCategory.PlaceholderText = "Enter category";
            tbxCategory.Size = new Size(210, 27);
            tbxCategory.TabIndex = 35;
            tbxCategory.TextChanged += tbxCategory_TextChanged;
            // 
            // tbxDescription
            // 
            tbxDescription.Location = new Point(137, 245);
            tbxDescription.Multiline = true;
            tbxDescription.Name = "tbxDescription";
            tbxDescription.PlaceholderText = "Enter description";
            tbxDescription.ScrollBars = ScrollBars.Vertical;
            tbxDescription.Size = new Size(210, 27);
            tbxDescription.TabIndex = 33;
            // 
            // lblDescription
            // 
            lblDescription.AutoSize = true;
            lblDescription.Font = new Font("Segoe UI", 10F);
            lblDescription.ForeColor = SystemColors.ControlLightLight;
            lblDescription.Location = new Point(39, 245);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(96, 23);
            lblDescription.TabIndex = 32;
            lblDescription.Text = "Description";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 10F);
            lblEmail.ForeColor = SystemColors.ControlLightLight;
            lblEmail.Location = new Point(13, 200);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(121, 23);
            lblEmail.TabIndex = 30;
            lblEmail.Text = "Stock Quantity";
            // 
            // lblPrice
            // 
            lblPrice.AutoSize = true;
            lblPrice.Font = new Font("Segoe UI", 10F);
            lblPrice.ForeColor = SystemColors.ControlLightLight;
            lblPrice.Location = new Point(87, 155);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(47, 23);
            lblPrice.TabIndex = 28;
            lblPrice.Text = "Price";
            // 
            // tbxName
            // 
            tbxName.Location = new Point(137, 65);
            tbxName.Name = "tbxName";
            tbxName.PlaceholderText = "Enter name";
            tbxName.Size = new Size(210, 27);
            tbxName.TabIndex = 27;
            tbxName.TextChanged += tbxName_TextChanged;
            // 
            // lbllName
            // 
            lbllName.AutoSize = true;
            lbllName.Font = new Font("Segoe UI", 10F);
            lbllName.ForeColor = SystemColors.ControlLightLight;
            lbllName.Location = new Point(78, 65);
            lbllName.Name = "lbllName";
            lbllName.Size = new Size(56, 23);
            lbllName.TabIndex = 26;
            lbllName.Text = "Name";
            // 
            // lblCategory
            // 
            lblCategory.AutoSize = true;
            lblCategory.Font = new Font("Segoe UI", 10F);
            lblCategory.ForeColor = SystemColors.ControlLightLight;
            lblCategory.Location = new Point(56, 110);
            lblCategory.Name = "lblCategory";
            lblCategory.Size = new Size(79, 23);
            lblCategory.TabIndex = 34;
            lblCategory.Text = "Category";
            // 
            // lblMsg
            // 
            lblMsg.Font = new Font("Segoe UI", 10F);
            lblMsg.ForeColor = Color.Gold;
            lblMsg.Location = new Point(7, 280);
            lblMsg.Name = "lblMsg";
            lblMsg.Size = new Size(370, 53);
            lblMsg.TabIndex = 40;
            lblMsg.Text = "Msg";
            lblMsg.TextAlign = ContentAlignment.MiddleCenter;
            lblMsg.Visible = false;
            // 
            // nudStockQuantity
            // 
            nudStockQuantity.Location = new Point(137, 200);
            nudStockQuantity.Maximum = new decimal(new int[] { 1316134911, 2328, 0, 0 });
            nudStockQuantity.Name = "nudStockQuantity";
            nudStockQuantity.Size = new Size(210, 27);
            nudStockQuantity.TabIndex = 42;
            nudStockQuantity.TextAlign = HorizontalAlignment.Right;
            nudStockQuantity.ThousandsSeparator = true;
            nudStockQuantity.ValueChanged += nudStockQuantity_ValueChanged;
            // 
            // nudPrice
            // 
            nudPrice.DecimalPlaces = 2;
            nudPrice.Location = new Point(137, 155);
            nudPrice.Maximum = new decimal(new int[] { 1316134911, 2328, 0, 0 });
            nudPrice.Name = "nudPrice";
            nudPrice.Size = new Size(210, 27);
            nudPrice.TabIndex = 41;
            nudPrice.TextAlign = HorizontalAlignment.Right;
            nudPrice.ThousandsSeparator = true;
            nudPrice.ValueChanged += nudPrice_ValueChanged;
            // 
            // tbxID
            // 
            tbxID.Location = new Point(137, 20);
            tbxID.Name = "tbxID";
            tbxID.PlaceholderText = "Enter ID";
            tbxID.Size = new Size(210, 27);
            tbxID.TabIndex = 43;
            tbxID.Visible = false;
            // 
            // lblNameRequired
            // 
            lblNameRequired.AutoSize = true;
            lblNameRequired.Font = new Font("Segoe UI", 12F);
            lblNameRequired.ForeColor = Color.Gold;
            lblNameRequired.Location = new Point(65, 65);
            lblNameRequired.Name = "lblNameRequired";
            lblNameRequired.Size = new Size(20, 28);
            lblNameRequired.TabIndex = 44;
            lblNameRequired.Text = "*";
            // 
            // lblPriceRequired
            // 
            lblPriceRequired.AutoSize = true;
            lblPriceRequired.Font = new Font("Segoe UI", 12F);
            lblPriceRequired.ForeColor = Color.Gold;
            lblPriceRequired.Location = new Point(74, 155);
            lblPriceRequired.Name = "lblPriceRequired";
            lblPriceRequired.Size = new Size(20, 28);
            lblPriceRequired.TabIndex = 46;
            lblPriceRequired.Text = "*";
            // 
            // lblStockQuantityRequired
            // 
            lblStockQuantityRequired.AutoSize = true;
            lblStockQuantityRequired.Font = new Font("Segoe UI", 12F);
            lblStockQuantityRequired.ForeColor = Color.Gold;
            lblStockQuantityRequired.Location = new Point(0, 200);
            lblStockQuantityRequired.Name = "lblStockQuantityRequired";
            lblStockQuantityRequired.Size = new Size(20, 28);
            lblStockQuantityRequired.TabIndex = 47;
            lblStockQuantityRequired.Text = "*";
            // 
            // FormProductInfo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(385, 393);
            Controls.Add(lblEmail);
            Controls.Add(lbllName);
            Controls.Add(lblPrice);
            Controls.Add(lblStockQuantityRequired);
            Controls.Add(lblPriceRequired);
            Controls.Add(lblNameRequired);
            Controls.Add(tbxID);
            Controls.Add(nudStockQuantity);
            Controls.Add(nudPrice);
            Controls.Add(lblMsg);
            Controls.Add(lblID);
            Controls.Add(btnCancel);
            Controls.Add(btnConfirm);
            Controls.Add(tbxCategory);
            Controls.Add(lblCategory);
            Controls.Add(tbxDescription);
            Controls.Add(lblDescription);
            Controls.Add(tbxName);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FormProductInfo";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Product";
            Load += FormProductInfo_Load;
            ((System.ComponentModel.ISupportInitialize)nudStockQuantity).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudPrice).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblID;
        private Button btnCancel;
        private Button btnConfirm;
        private TextBox tbxCategory;
        private TextBox tbxDescription;
        private Label lblDescription;
        private Label lblEmail;
        private Label lblPrice;
        private TextBox tbxName;
        private Label lbllName;
        private Label lblCategory;
        private Label lblMsg;
        private NumericUpDown nudStockQuantity;
        private NumericUpDown nudPrice;
        private TextBox tbxID;
        private Label lblNameRequired;
        private Label lblPriceRequired;
        private Label lblStockQuantityRequired;
    }
}