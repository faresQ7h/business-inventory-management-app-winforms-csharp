﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Business_Inventory_Management_System
{
    public class ActiveCustomerSummary
    {
        public Customer Customer { get; set; }
        public string DisplayText => $"{Customer.DisplayCode} | {Customer.FirstName} | {Customer.LastName} | {Customer.Phone} | ({Customer.Email})";
        public int OrdersCount { get; set; }
        public decimal TotalSpent { get; set; }

        public static List<ActiveCustomerSummary> BuildMostActiveCustomers()
        {
            Dictionary<Customer, ActiveCustomerSummary> customerStats =
                new Dictionary<Customer, ActiveCustomerSummary>();

            int totalOrders = 0;

            // 1️- data per customer
            foreach (Order order in FormOrders.Orders)
            {
                if (order.Status == "Cancelled")
                    continue;
                if (!customerStats.ContainsKey(order.Customer))
                {
                    customerStats[order.Customer] = new ActiveCustomerSummary
                    {
                        Customer = order.Customer,
                        OrdersCount = 0,
                        TotalSpent = 0
                    };
                }

                customerStats[order.Customer].OrdersCount++;
                customerStats[order.Customer].TotalSpent += order.TotalPrice;
            }

            if (customerStats.Count == 0)
                return new List<ActiveCustomerSummary>();

            // 2️- Calculate average order count
            double averageOrders =
                (double)totalOrders / customerStats.Count;

            // 3️- Keep customers above average
            List<ActiveCustomerSummary> mostActive = new List<ActiveCustomerSummary>();

            foreach (ActiveCustomerSummary summary in customerStats.Values)
            {
                if (summary.OrdersCount > averageOrders)
                    mostActive.Add(summary);
            }

            return mostActive;
        }
    }
}
