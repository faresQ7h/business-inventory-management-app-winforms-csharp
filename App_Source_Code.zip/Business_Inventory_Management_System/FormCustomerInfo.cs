﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Business_Inventory_Management_System
{
    public partial class FormCustomerInfo : Form
    {
        //
        //
        //
        private char _Mode;// S = serech, E = edit, A = add
        private Customer _SelectedCustomer;

        public FormCustomerInfo(char whichMode) //when Adding/Searching
        {
            InitializeComponent();
            this._Mode = whichMode;
        }

        public FormCustomerInfo(char whichMode, Customer Customer) //when Editing
        {
            InitializeComponent();
            this._Mode = whichMode;
            this._SelectedCustomer = Customer;
        }
        //
        //
        //
        public FormCustomerInfo()
        {
            InitializeComponent();
        }

        private void FormCustomerInfo_Load(object sender, EventArgs e)
        {
            if (_Mode == 'S')
            {
                lblID.Visible = true;
                tbxID.Visible = true;

                lblFirstNameRequired.Visible = false;
                lblLastNameRequired.Visible = false;
                lblPhoneNameRequired.Visible = false;
                lblEmailRequired.Visible = false;

                Helpers.AvtivateButton(btnConfirm, Color.LightSeaGreen);
                lblMsg.Visible = false;
                return;
            }

            lblMsg.Text = "Fields marked with (*) are required.";
            lblMsg.Visible = true;

            if (_Mode == 'E')
            {
                tbxFirstName.Text = _SelectedCustomer.FirstName;
                tbxLastName.Text = _SelectedCustomer.LastName;
                tbxEmail.Text = _SelectedCustomer.Email;
                tbxPhoneNumber.Text = _SelectedCustomer.Phone;
                tbxAddress.Text = _SelectedCustomer.Address;
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (_Mode == 'S')
            {
                if (!string.IsNullOrWhiteSpace(tbxID.Text))
                {
                    if (!Helpers.IsValidIDInput(tbxID.Text, "COS"))
                    {
                        tbxID.Clear();
                        lblMsg.Text = "Invalid ID format. Please enter a number or a code like COS-123";
                        lblMsg.Visible = true;
                        return;
                    }
                    FormCustomers.ID = Helpers.GetIDNumberOnly(tbxID.Text);
                }
                else
                {
                    FormCustomers.ID = 0;
                }
                SendDataBackAndClose();
                return;
            }


            //in case of Add or Edite
            SendDataBackAndClose();
        }

        private void tbxFirstName_TextChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void tbxLastName_TextChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void tbxPhoneNumber_TextChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void tbxEmail_TextChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        void UpdateConfirmButton()
        {
            if (!string.IsNullOrEmpty(tbxFirstName.Text) &&
                !string.IsNullOrEmpty(tbxLastName.Text) &&
                !string.IsNullOrEmpty(tbxEmail.Text) &&
                !string.IsNullOrEmpty(tbxPhoneNumber.Text))
                Helpers.AvtivateButton(btnConfirm, Color.LightSeaGreen);
            else
                Helpers.DeavtivateButton(btnConfirm, Color.DarkSlateGray);
        }

        void SendDataBackAndClose()
        {

            FormCustomers.FirstName = (tbxFirstName.Text ?? "").Trim();
            FormCustomers.LastName = (tbxLastName.Text ?? "").Trim();
            FormCustomers.Email = (tbxEmail.Text ?? "").Trim();
            FormCustomers.Phone = string.Join(" ", tbxPhoneNumber.Text.Split(' ', StringSplitOptions.RemoveEmptyEntries));
            FormCustomers.Address = (tbxAddress.Text ?? "").Trim();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
