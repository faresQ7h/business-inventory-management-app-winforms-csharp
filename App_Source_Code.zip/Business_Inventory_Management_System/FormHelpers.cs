﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Business_Inventory_Management_System
{
    public static class Helpers
    {
        public static string? SelectedBusinessName { get; private set; }
        public static string? SelectedBusinessPath { get; private set; }


        public static readonly string appDataFolderPath =
         Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

        public static readonly string systemDataFolderPath =
            Path.Combine(appDataFolderPath, "MyBusinessInventoryApp");

        public static string[] systemBusinessesList;

        static Helpers()
        {
            // 1️ Ensure folder exists
            Directory.CreateDirectory(systemDataFolderPath);

            // 2️ Load businesses
            systemBusinessesList = Directory.GetDirectories(systemDataFolderPath)
             .Select(path => Path.GetFileName(path) ?? string.Empty)
             .ToArray();
        }

        public static void SetSelectedBusiness(string businessName)
        {
            SelectedBusinessName = businessName;
            SelectedBusinessPath = Path.Combine(systemDataFolderPath, businessName);
        }

        public static void ClearSelectedBusiness()
        {
            SelectedBusinessName = null;
            SelectedBusinessPath = null;
        }

        public static void LoadFormIntoPanel(Form form, Panel panel)
        {
            if (panel.Controls.Count > 0 &&
                panel.Controls[0] is Form current &&
                current.GetType() == form.GetType())
            {
                form.Dispose();
                return;
            }

            foreach (Control ctrl in panel.Controls)
            {
                if (ctrl is Form f)
                    f.Close();   // ✅ triggers FormClosing
                else
                    ctrl.Dispose();
            }

            panel.Controls.Clear();

            form.TopLevel = false;
            form.Dock = DockStyle.Fill;
            panel.Controls.Add(form);
            form.Show();
        }


        public static void DeavtivateButton(Button btn, Color clr)
        {
            btn.Enabled = false;
            btn.BackColor = clr;
        }

        public static void AvtivateButton(Button btn, Color clr)
        {
            btn.Enabled = true;
            btn.BackColor = clr; 
        }

        public static void AvtivateTextBox(TextBox tbx, Color clr)
        {
            tbx.BackColor = clr;
            tbx.Enabled = true;
        }

        public static void DeavtivateTextBox(TextBox tbx, Color clr)
        {
            tbx.BackColor = clr;
            tbx.Enabled = false;
        }

        public static bool PasswordsAreSame(string s1, string s2)
        {
            return s1.Equals(s2);
        }

        public static void RefreshBusinessesList()
        {
            systemBusinessesList = Directory.GetDirectories(systemDataFolderPath)
                .Select(path => Path.GetFileName(path) ?? string.Empty)
                .ToArray();
        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create()) //Use it, then clean it from memory automatically
            {
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha.ComputeHash(bytes);

                return Convert.ToBase64String(hash);
            }
        }

        public static void ChangeHideOrShowPassword(TextBox tbx)
        {
            if (tbx.PasswordChar == '\0')
                tbx.PasswordChar = '*';
            else
                tbx.PasswordChar = '\0';
        }

        public static string CapitalizeFirst(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return name;

            name = name.Trim();

            return char.ToUpper(name[0]) + name.Substring(1).ToLower();
        }

        public static BindingList<T> LoadJsonToBindingList<T>(string fileName)
        {
            string filePath = Path.Combine(SelectedBusinessPath, fileName);

            if (!File.Exists(filePath))
                return new BindingList<T>();

            string json = File.ReadAllText(filePath);

            List<T> list =
                JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();

            return new BindingList<T>(list);
        }

        public static void SaveBindingListToJson<T>(
            BindingList<T> bindingList,
            string fileName)
        {
            string filePath = Path.Combine(SelectedBusinessPath, fileName);

            string json = JsonSerializer.Serialize(
                bindingList.ToList(),
                new JsonSerializerOptions { WriteIndented = true }
            );

            File.WriteAllText(filePath, json);
        }

        public static bool IsValidIDInput(string input, string prefix)
        {
            input = input.Trim();

            return Regex.IsMatch(input, $@"^({prefix}-\d+|\d+)$");
        }

        public static long GetIDNumberOnly(string id)
        {
            id = id.Trim();

            // If it contains '-', take the part after it
            int dashIndex = id.IndexOf('-');
            if (dashIndex >= 0)
                return long.Parse(id.Substring(dashIndex + 1));

            // Otherwise it's already just a number
            return long.Parse(id);
        }
    }
}
