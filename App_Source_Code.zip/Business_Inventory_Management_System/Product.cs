﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Business_Inventory_Management_System
{
    public class Product : INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler? PropertyChanged;
        public long ID { get; set; }
        public string DisplayCode => $"PRO-{ID}";
        public string DisplayText => $"{DisplayCode} | {Name} | {Category} | {Price} $";

        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                if (_name == value) return;
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        private string _category;
        public string Category
        {
            get => _category;
            set
            {
                if (_category == value) return;
                _category = value;
                OnPropertyChanged(nameof(Category));
            }
        }

        private decimal _price;
        public decimal Price
        {
            get => _price;
            set
            {
                if (_price == value) return;
                _price = value;
                OnPropertyChanged(nameof(Price));
            }
        }

        private int _stockQuantity;
        public int StockQuantity
        {
            get => _stockQuantity;
            set
            {
                if (_stockQuantity == value) return;
                _stockQuantity = value;
                OnPropertyChanged(nameof(StockQuantity));
            }
        }

        private string _description;
        public string Description
        {
            get => _description;
            set
            {
                if (_description == value) return;
                _description = value;
                OnPropertyChanged(nameof(Description));
            }
        }

        private static long IDSeed = 0;

        public Product() {}

        public Product(string name, decimal price, int stockQuantity, string category = "", string descreption = "")
        {
            this.Name = name;
            this.Category = category;
            this.Price = price;
            this.StockQuantity = stockQuantity;
            this.Description = descreption;
            this.ID = ++IDSeed;
        }

        public static void InitializeIDSeed(BindingList<Product> plist)
        {
            if (plist == null)
                return;
            IDSeed = 0;
            foreach (Product p in plist)
            {
                if (p.ID > IDSeed)
                    IDSeed = p.ID;
            }

        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
