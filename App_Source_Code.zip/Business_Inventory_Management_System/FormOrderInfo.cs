﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormOrderInfo : Form
    {

        //
        //
        //
        private char _Mode;// S = serech, E = edit, A = add
        private Order _SelectedOrder;
        private BindingList<OrderItem> _Items = new BindingList<OrderItem>();

        public FormOrderInfo(char whichMode) //when Adding ans Searching
        {
            InitializeComponent();
            this._Mode = whichMode;
        }

        public FormOrderInfo(char whichMode, Order Order) //when Editing
        {
            InitializeComponent();
            this._Mode = whichMode;
            this._SelectedOrder = Order;
        }
        //
        //
        //

        private void FormOrderInfo_Load(object sender, EventArgs e)
        {
            //
            //load data
            FormatOrderItemsGrid();
            dgvOrderItems.DataSource = _Items;

            //Combo Customers:
            comboCustomer.DisplayMember = "DisplayText";
            comboCustomer.DataSource = FormCustomers.Customers;

            //Combo Products:
            comboProducts.DisplayMember = "DisplayText";
            comboProducts.DataSource = FormProducts.Products;
            //
            //


            if (_Mode == 'S')
            {
                lblID.Visible = true;
                tbxID.Visible = true;

                dtpEstimatedDeliveryDate.ShowCheckBox = true;

                lblCustomerRequired.Visible = false;
                lblStatusRequired.Visible = false;
                lblEstimatedDeliveryRequired.Visible = false;
                lblItemProductRequired.Visible = false;
                lblItemQuantityRequired.Visible = false;

                Helpers.AvtivateButton(btnConfirm, Color.LightSeaGreen);
                lblMsg.Visible = false;
                lblEmptyOrderItems.Visible = false;
                return;
            }

            lblMsg.Text = "Fields marked with (*) are required.";
            lblMsg.Visible = true;
            UpdateEmptyOrderItemsLabel();

            if (_Mode == 'E')
            {
                comboCustomer.SelectedItem = _SelectedOrder.Customer;
                comboStatus.SelectedItem = _SelectedOrder.Status;
                dtpEstimatedDeliveryDate.Value = _SelectedOrder.EstimatedDeliveryDate;
                tbxDescription.Text = _SelectedOrder.Description;
                _Items = _SelectedOrder.Items;
                dgvOrderItems.DataSource = _Items;
                UpdateDeleteItemButton();
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (_Mode == 'S')
            {
                if (!string.IsNullOrWhiteSpace(tbxID.Text))
                {
                    if (!Helpers.IsValidIDInput(tbxID.Text, "ORD"))
                    {
                        tbxID.Clear();
                        lblMsg.Text = "Invalid ID format. Please enter a number or a code like ORD-123";
                        lblMsg.Visible = true;
                        return;
                    }
                    FormOrders.ID = Helpers.GetIDNumberOnly(tbxID.Text);
                }
                else
                {
                    FormCustomers.ID = 0;
                }
                SendDataBackAndClose();
                return;
            }


            //in case of Add or Edite
            SendDataBackAndClose();
        }
        //
        //
        //DGV add or delet Items
        private void btnAdd_Click(object sender, EventArgs e)
        {
            _Items.Add(new OrderItem(
                comboProducts.SelectedItem as Product,
                (int)nudQuantity.Value
            ));
            comboProducts.SelectedItem = null;
            nudQuantity.Value = 0;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            _Items.Remove(dgvOrderItems.CurrentRow.DataBoundItem as OrderItem);
        }
        //DGV add or delet Items
        //
        //

        private void comboCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void comboStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_Mode != 'S')
                UpdateConfirmButton();
        }

        private void dgvOrderItems_SelectionChanged(object sender, EventArgs e)
        {
            UpdateDeleteItemButton();
        }


        //
        //Allow quantity edit on a row double click
        private void dgvOrderItems_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) //the header
                return;

            int qtyColIndex = -1;

            foreach (DataGridViewColumn col in dgvOrderItems.Columns) // get the quantity qolumn index
            {
                if (col.DataPropertyName == "Quantity")
                {
                    qtyColIndex = col.Index;
                    break;
                }
            }

            if (qtyColIndex == -1)
                return;

            dgvOrderItems.CurrentCell =
                dgvOrderItems.Rows[e.RowIndex].Cells[qtyColIndex];

            dgvOrderItems.BeginEdit(true);
        }
        private void dgvOrderItems_CellValidating(object sender, DataGridViewCellValidatingEventArgs e) //fires befor cell value is accepeted
        {
            // Check only Quantity column
            if (dgvOrderItems.Columns[e.ColumnIndex].DataPropertyName != "Quantity")
                return;

            if (!int.TryParse(e.FormattedValue.ToString(), out int qty) || qty <= 0)
            {
                MessageBox.Show(
                    "Quantity must be a fixed number greater than 0.",
                    "Invalid quantity",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );

                e.Cancel = true; // ❌ reject edit
            }
        }
        private void dgvOrderItems_CellEndEdit(object sender, DataGridViewCellEventArgs e) //update total after finish
        {
            UpdateTotalLabel();
            UpdateConfirmButton();
        }
        //
        //


        //
        //updates labels and delete button when row is added or removed to the DGV
        private void dgvOrderItems_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (_Mode != 'S')
            {
                UpdateEmptyOrderItemsLabel();
                UpdateConfirmButton();
            }
            UpdateTotalLabel();
            UpdateDeleteItemButton();
            
        }
        private void dgvOrderItems_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (_Mode != 'S')
            {
                UpdateEmptyOrderItemsLabel();
                UpdateConfirmButton();
            }
            UpdateTotalLabel();
            UpdateDeleteItemButton();
        }
        //
        //


        //
        //update Add button
        private void comboProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboProducts.SelectedItem == null)
                return;

            var selectedProduct = comboProducts.SelectedItem as Product;

            bool alreadyAdded = _Items.Any(i => i.Product == selectedProduct); //loop through each item and check if it is already there

            if (alreadyAdded)
            {
                MessageBox.Show(
                    $"This product ({selectedProduct.DisplayText}) is already added to the order.",
                    "Duplicate product",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                comboProducts.SelectedItem = null;
                return;
            }
            UpdateAddItemButton();

        }
        private void nudQuantity_ValueChanged(object sender, EventArgs e)
        {
            UpdateAddItemButton();
        }
        //
        //


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }




        //
        //Used Functions
        void UpdateConfirmButton()
        {
            if (comboCustomer.SelectedItem != null &&
                comboStatus.SelectedItem != null &&
                _Items.Count > 0)
            {
                Helpers.AvtivateButton(btnConfirm, Color.LightSeaGreen);
            }
            else
            {
                Helpers.DeavtivateButton(btnConfirm, Color.DarkSlateGray);
            }
        }

        void UpdateEmptyOrderItemsLabel()
        {
            if (_Items.Count > 0) lblEmptyOrderItems.Visible = false;
            else lblEmptyOrderItems.Visible = true;
        }

        void UpdateTotalLabel()
        {
            decimal total = 0;
            foreach (OrderItem item in _Items)
            {
                total += (item.Product.Price * item.Quantity);
            }
            lblTotal.Text = $"Total: {total.ToString()}$";
        }

        void UpdateDeleteItemButton()
        {
            if (_Items.Count > 0 && dgvOrderItems.SelectedRows.Count > 0)
                Helpers.AvtivateButton(btnDelete, btnDelete.BackColor);
            else
                Helpers.DeavtivateButton(btnDelete, btnDelete.BackColor);
        }

        void UpdateAddItemButton()
        {
            if (comboProducts.SelectedItem != null &&
                nudQuantity.Value > 0)
            {
                Helpers.AvtivateButton(btnAdd, btnAdd.BackColor);
            }
            else
            {
                Helpers.DeavtivateButton(btnAdd, btnAdd.BackColor);
            }
        }

        private void FormatOrderItemsGrid()
        {
            dgvOrderItems.AutoGenerateColumns = false;
            dgvOrderItems.Columns.Clear();

            var colId = new DataGridViewTextBoxColumn
            {
                HeaderText = "ID",
                DataPropertyName = "ProductID",
                ReadOnly = true
            };

            var colName = new DataGridViewTextBoxColumn
            {
                HeaderText = "Product Name",
                DataPropertyName = "ProductName",
                ReadOnly = true,
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            };

            var colQty = new DataGridViewTextBoxColumn
            {
                HeaderText = "Quantity",
                DataPropertyName = "Quantity",
                ReadOnly = false
            };

            dgvOrderItems.Columns.AddRange(colId, colName, colQty); // we add the columns created
        }

        void SendDataBackAndClose()
        {

            FormOrders.Customer = comboCustomer.SelectedItem as Customer;
            FormOrders.Status = comboStatus.SelectedItem as string;
            if (dtpEstimatedDeliveryDate.Checked == true)
                FormOrders.EstimatedDelivary = dtpEstimatedDeliveryDate.Value;
            else
                FormOrders.EstimatedDelivary = null;
            FormOrders.Description = tbxDescription.Text;
            FormOrders.Items = _Items;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
