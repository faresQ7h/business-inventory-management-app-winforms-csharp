﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormChangePassword : Form
    {
        public FormChangePassword()
        {
            InitializeComponent();
        }
        private void tbxOldPassword_TextChanged(object sender, EventArgs e)
        {
            UpdateConfirmButton();
        }

        private void tbxNewPassword_TextChanged(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(tbxNewPassword.Text))
            {
                Helpers.AvtivateTextBox(tbxConfirmPassword, SystemColors.Window);
                Helpers.AvtivateButton(btnShowOrHideConfirmPass, btnShowOrHideConfirmPass.BackColor);
            }
            else
            {
                Helpers.DeavtivateTextBox(tbxConfirmPassword, Color.DarkGray);
                Helpers.DeavtivateButton(btnShowOrHideConfirmPass, btnShowOrHideConfirmPass.BackColor);
            }
            UpdatePasswordNotMatchLabel();
            UpdateConfirmButton();
        }

        private void tbxConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            UpdatePasswordNotMatchLabel();
            UpdateConfirmButton();
        }

        private void btnOlsPassword_Click(object sender, EventArgs e)
        {
            Helpers.ChangeHideOrShowPassword(tbxOldPassword);
        }

        private void btnShowOrHideNewPass_Click(object sender, EventArgs e)
        {
            Helpers.ChangeHideOrShowPassword(tbxNewPassword);
        }

        private void btnShowOrHideConfirmPass_Click(object sender, EventArgs e)
        {
            Helpers.ChangeHideOrShowPassword(tbxConfirmPassword);
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (!IsCorrectPassword())
            {
                lblPasswordWrong.Visible = true;
                tbxOldPassword.Clear();
                return;
            }

            DialogResult result = MessageBox.Show(
            "Are you sure you want to change your password?\n\n" +
            "This action cannot be undone, and the old password cannot be recovered.",
            "Confirm Password Change",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            string passwordPath = Path.Combine(Helpers.SelectedBusinessPath, "Password.txt");
            File.WriteAllText(
                passwordPath,
                Helpers.HashPassword(tbxNewPassword.Text)
            );

            lblSuccessfulSaved.Visible = true;

            tbxOldPassword.Clear();
            tbxNewPassword.Clear();
            tbxConfirmPassword.Clear();

            lblPasswordWrong.Visible = false;
            lblPasswordsNotMatch.Visible = false;
        }

        void UpdateConfirmButton()
        {
            if (!string.IsNullOrWhiteSpace(tbxOldPassword.Text) &&
                !string.IsNullOrWhiteSpace(tbxNewPassword.Text) &&
                !string.IsNullOrWhiteSpace(tbxConfirmPassword.Text) &&
                Helpers.PasswordsAreSame(tbxNewPassword.Text, tbxConfirmPassword.Text))
                Helpers.AvtivateButton(btnConfirm, Color.LightSeaGreen);
            else
                Helpers.DeavtivateButton(btnConfirm, Color.DarkSlateGray);
        }

        private void UpdatePasswordNotMatchLabel()
        {
            if (!Helpers.PasswordsAreSame(tbxNewPassword.Text, tbxConfirmPassword.Text))
            {
                lblPasswordsNotMatch.Visible = true;
            }
            else
            {
                lblPasswordsNotMatch.Visible = false;
            }
        }

        private bool IsCorrectPassword()
        {
            string passwordFile = Path.Combine(Helpers.SelectedBusinessPath, "Password.txt");

            //check file exists
            if (!File.Exists(passwordFile))
                return false;

            string savedHash = File.ReadAllText(passwordFile);
            string enteredHash = Helpers.HashPassword(tbxOldPassword.Text);

            return string.Equals(savedHash, enteredHash, StringComparison.Ordinal);
        }
    }
}
