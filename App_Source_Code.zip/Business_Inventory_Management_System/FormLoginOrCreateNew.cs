﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Inventory_Management_System
{
    public partial class FormLoginOrCreateNew : Form
    {
        public FormLoginOrCreateNew()
        {
            InitializeComponent();
        }


        private void FormLoginOrCreateNew_Load(object sender, EventArgs e)
        {
            FormLogin loginForm = new FormLogin();
            loginForm.LoginSucceeded += LoginForm_LoginSucceeded;
            Helpers.LoadFormIntoPanel(loginForm, panelShowOption);
        }

        private void btnLogInOption_Click(object sender, EventArgs e)
        {
            //we need to subsecribe to the event again because the form is being disposed
            //and created again with completely new identity, so even they have the same name,
            //they are deffirent under the hood
            //think of it like, if I dont update it, it is like I am subscribed to an old non-existing form event
            FormLogin loginForm = new FormLogin();
            loginForm.LoginSucceeded += LoginForm_LoginSucceeded;
            Helpers.LoadFormIntoPanel(loginForm, panelShowOption);
            btnCreateNewOption.BackColor = Color.Gray;
            btnLogInOption.BackColor = Color.Teal;
        }

        private void btnCreateNewOption_Click(object sender, EventArgs e)
        {
            Helpers.LoadFormIntoPanel(new FormCreate(), panelShowOption);
            btnLogInOption.BackColor = Color.Gray;
            btnCreateNewOption.BackColor = Color.Teal;
        }

        private void LoginForm_LoginSucceeded(object? sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
